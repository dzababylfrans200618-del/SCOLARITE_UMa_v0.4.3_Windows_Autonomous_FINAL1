# SCOLARITÉ UMa

Application graphique Linux de gestion de la scolarité de l'Université de Maroua.

## Version 0.4.0 — extension TPE LMD

Cette version ajoute les modules de comptes, sessions d'examens, évaluations, saisie/validation/publication des notes, calculs UE/semestre, emplois du temps, historique et relevé PDF. Les menus sont filtrés selon le rôle connecté. La base reste vide : les référentiels et dossiers sont à créer ou à importer.

Les imports CSV/XLSX restent disponibles pour les étudiants, facultés, départements, filières, niveaux, années académiques, enseignants, UE, cours et inscriptions. Les comptes sont créés individuellement par l'administrateur afin de ne pas importer des mots de passe depuis des tableurs.

Les paramètres de calcul LMD (10/20, 20 points maximum, 30 crédits par semestre, pondération par coefficients et crédits) sont des hypothèses de démonstration, modifiables. Ils ne doivent pas être présentés comme le règlement officiel de l'Université sans confirmation.

Voir `docs/ETAT_LIVRAISON.md` pour les fonctions, limites et tests réellement effectués et `docs/REGLES_LMD_TPE.md` pour le scénario académique.

## Installation et lancement local

Pré-requis : Linux 64 bits, Python 3.11+, accès réseau pour installer les dépendances.

Terminal 1 — serveur :

```bash
cd SCOLARITE_UMa/server
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Terminal 2 — client :

```bash
cd SCOLARITE_UMa
./scripts/install-client-linux.sh
scolarite-uma
```

Créer le compte administrateur (après démarrage du serveur) :

```bash
cd SCOLARITE_UMa/server
.venv/bin/python -m app.seed_admin
```

## Mettre à jour une installation existante

Après extraction de l'archive de mise à jour :

```bash
bash /chemin/vers/SCOLARITE_UMa/scripts/apply-update.sh \
  /chemin/vers/SCOLARITE_UMa_v0.4.0.zip \
  /chemin/vers/installation/SCOLARITE_UMa
```

Puis mettre à jour les dépendances du serveur :

```bash
cd /chemin/vers/installation/SCOLARITE_UMa/server
.venv/bin/pip install -r requirements.txt
```

Le script conserve la base de données, `.env` et les environnements virtuels, et sauvegarde les dossiers de code remplacés. Arrêtez le serveur et l'application avant la mise à jour.

## Import CSV / Excel

Dans la page concernée, cliquez sur **Modèle Excel**, remplissez la première feuille sans modifier les noms de colonnes, puis cliquez sur **Importer CSV / Excel**. Sélectionnez le fichier, lancez **Analyser le fichier**, corrigez les erreurs éventuellement listées, puis cliquez sur **Importer les données**. L'ordre d'import des référentiels liés est : facultés → départements → filières → niveaux et années → enseignants → UE → cours → étudiants → inscriptions.

La documentation API est accessible à `http://127.0.0.1:8000/api/docs`.

## Mise en production

Cette livraison n'est pas certifiée pour un déploiement de production universitaire. Avant mise en service : utiliser PostgreSQL, définir des secrets robustes dans `.env`, placer l'API derrière HTTPS, limiter l'accès réseau, réaliser des sauvegardes et tester une restauration, puis exécuter les tests d'acceptation avec la scolarité et les responsables pédagogiques.

## Installation Windows autonome (v0.4.3)

Une édition Windows 10/11 64 bits est préparée avec un installateur unique `SCOLARITE_UMa_Setup.exe`. Elle regroupe le client PySide6, l'API FastAPI locale et une base SQLite locale. Python, PostgreSQL et Docker ne sont pas requis sur le poste Windows. Les données sont conservées dans `C:\ProgramData\SCOLARITE UMa\data` et les journaux dans `C:\ProgramData\SCOLARITE UMa\logs`.

Le premier compte administrateur est créé par l'assistant lancé à la fin de l'installation. Le workflow GitHub Actions `.github/workflows/build-windows.yml` construit l'installateur sur un runner Windows. Voir `docs/WINDOWS_INSTALLATION_LOCALE.md` pour les détails, la sauvegarde et les limites. Cette édition est monoposte ; elle ne remplace pas l'architecture Linux/PostgreSQL destinée à un serveur partagé.

import os
import sys
import time
import subprocess
from pathlib import Path
import requests
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QTableWidget, QTableWidgetItem, QMessageBox,
    QDialog, QFormLayout, QComboBox, QStackedWidget, QFrame, QScrollArea,
    QHeaderView, QButtonGroup, QTextEdit, QFileDialog, QInputDialog
)

API_URL = os.getenv("SCOLARITE_API_URL", "http://127.0.0.1:8000").rstrip("/")
_LOCAL_SERVER_PROCESS = None

def ensure_local_server():
    """Démarre l'API empaquetée sur Windows, sans modifier le lancement Linux."""
    global _LOCAL_SERVER_PROCESS
    if sys.platform != "win32":
        return
    health_url = API_URL + "/health"
    try:
        if requests.get(health_url, timeout=1).ok:
            return
    except requests.RequestException:
        pass
    server_exe = Path(sys.executable).with_name("SCOLARITE-UMa-Serveur.exe")
    if not server_exe.exists():
        raise RuntimeError("Le serveur local SCOLARITÉ UMa est introuvable. Réinstallez l'application.")
    env = os.environ.copy()
    data_dir = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "SCOLARITE UMa" / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    env["SCOLARITE_DATA_DIR"] = str(data_dir)
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    _LOCAL_SERVER_PROCESS = subprocess.Popen(
        [str(server_exe)], cwd=str(server_exe.parent), env=env,
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        creationflags=creationflags
    )
    for _ in range(40):
        if _LOCAL_SERVER_PROCESS.poll() is not None:
            raise RuntimeError(r"Le serveur local n'a pas pu démarrer. Vérifiez les journaux dans ProgramData\SCOLARITE UMa\logs.")
        try:
            if requests.get(health_url, timeout=1).ok:
                return
        except requests.RequestException:
            time.sleep(0.5)
    raise RuntimeError("Le serveur local met trop de temps à démarrer.")

STYLE = """
QWidget { background:#f4f6fa; color:#182235; font-family:'Noto Sans'; font-size:13px; }
QLabel#title { font-size:25px; font-weight:700; color:#12233f; min-height:40px; padding-top:3px; padding-bottom:2px; background:transparent; }
QLabel#muted { color:#718096; }
QLineEdit, QComboBox, QTextEdit { background:white; border:1px solid #d9e0ea; border-radius:7px; padding:9px; min-height:20px; }
QPushButton { background:#183b66; color:white; border:0; border-radius:7px; padding:10px 16px; font-weight:600; }
QPushButton:hover { background:#24558d; }
QPushButton#secondary { background:#e5ebf3; color:#183b66; }
QPushButton#danger { background:#a83242; }
QPushButton#nav { text-align:left; background:transparent; color:#dce7f5; padding:9px 11px; border-radius:6px; }
QPushButton#nav:hover { background:#244363; }
QPushButton#nav:checked { background:#315b88; color:white; }
QLabel#navheading { color:#8fa8c4; font-size:10px; font-weight:700; padding:12px 10px 4px 10px; }
QTableWidget { background:white; border:1px solid #e0e6ee; border-radius:8px; gridline-color:#edf0f5; selection-background-color:#dce9f8; selection-color:#14233b; }
QHeaderView::section { background:#edf2f8; color:#24364d; padding:10px 8px; min-height:28px; border:0; font-weight:700; }
QFrame#card { background:white; border:1px solid #e3e8ef; border-radius:10px; }
QFrame#sidebar { background:#122945; }
"""

class Api:
    def __init__(self):
        self.token = None

    def call(self, method, path, **kwargs):
        headers = dict(kwargs.pop("headers", {}))
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        timeout = kwargs.pop("timeout", 30)
        response = requests.request(method, API_URL + path, headers=headers, timeout=timeout, **kwargs)
        if response.status_code >= 400:
            try:
                message = response.json().get("detail", "Erreur du serveur")
            except Exception:
                message = response.text[:300]
            raise RuntimeError(str(message))
        return response.json() if response.content else None

    def login(self, username, password):
        data = self.call("POST", "/auth/login", data={"username": username, "password": password})
        self.token = data["access_token"]
        return data

    def import_file(self, entity, file_path, dry_run=True):
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        with open(file_path, "rb") as handle:
            response = requests.post(
                f"{API_URL}/imports/{entity}",
                params={"dry_run": "true" if dry_run else "false"},
                files={"file": (os.path.basename(file_path), handle)},
                headers=headers, timeout=(10, 180),
            )
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", "Erreur du serveur")
            except Exception:
                detail = response.text[:500]
            raise RuntimeError(str(detail))
        return response.json()

    def download_import_template(self, entity, file_path, file_format="xlsx"):
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        response = requests.get(
            f"{API_URL}/imports/{entity}/template",
            params={"format": file_format}, headers=headers, timeout=30,
        )
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", "Erreur du serveur")
            except Exception:
                detail = response.text[:500]
            raise RuntimeError(str(detail))
        with open(file_path, "wb") as handle:
            handle.write(response.content)


class LoginWindow(QWidget):
    def __init__(self, api):
        super().__init__()
        self.api = api
        self.setWindowTitle("SCOLARITÉ UMa — Connexion")
        self.setFixedSize(430, 390)
        root = QVBoxLayout(self)
        root.setContentsMargins(36, 30, 36, 30)
        root.setSpacing(13)
        brand = QLabel("SCOLARITÉ UMa")
        brand.setObjectName("title")
        brand.setAlignment(Qt.AlignCenter)
        subtitle = QLabel("Système de gestion académique")
        subtitle.setObjectName("muted")
        subtitle.setAlignment(Qt.AlignCenter)
        root.addStretch()
        root.addWidget(brand)
        root.addWidget(subtitle)
        root.addSpacing(20)
        self.username = QLineEdit()
        self.username.setPlaceholderText("Identifiant")
        self.password = QLineEdit()
        self.password.setPlaceholderText("Mot de passe")
        self.password.setEchoMode(QLineEdit.Password)
        root.addWidget(self.username)
        root.addWidget(self.password)
        btn = QPushButton("Se connecter")
        btn.clicked.connect(self.submit)
        root.addWidget(btn)
        self.status = QLabel("")
        self.status.setObjectName("muted")
        self.status.setAlignment(Qt.AlignCenter)
        root.addWidget(self.status)
        root.addStretch()
        self.password.returnPressed.connect(self.submit)

    def submit(self):
        try:
            data = self.api.login(self.username.text().strip(), self.password.text())
            self.main = MainWindow(self.api, data)
            self.main.show()
            self.close()
        except Exception as exc:
            self.status.setText(str(exc))


class StudentDialog(QDialog):
    FIELDS = [
        ("matricule", "Matricule"), ("last_name", "Nom"),
        ("first_name", "Prénom(s)"), ("sex", "Sexe"),
        ("birth_date", "Date de naissance (AAAA-MM-JJ)"), ("phone", "Téléphone"), ("email", "Courriel"),
        ("program", "Filière (code ou intitulé)"), ("level", "Niveau")
    ]

    def __init__(self, parent=None, student=None):
        super().__init__(parent)
        self.setWindowTitle("Dossier étudiant")
        self.setMinimumWidth(450)
        self.fields = {}
        form = QFormLayout(self)
        for key, label in self.FIELDS:
            widget = QComboBox() if key == "sex" else QLineEdit()
            if key == "sex":
                widget.addItems(["", "M", "F"])
            self.fields[key] = widget
            form.addRow(label, widget)
        if student:
            for key, widget in self.fields.items():
                value = student.get(key, "") or ""
                if isinstance(widget, QComboBox):
                    widget.setCurrentText(str(value))
                else:
                    widget.setText(str(value))
        buttons = QHBoxLayout()
        cancel = QPushButton("Annuler")
        cancel.setObjectName("secondary")
        save = QPushButton("Enregistrer")
        cancel.clicked.connect(self.reject)
        save.clicked.connect(self.accept)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        form.addRow(buttons)

    def values(self):
        values = {key: (widget.currentText() if isinstance(widget, QComboBox) else widget.text().strip())
                  for key, widget in self.fields.items()}
        if not values.get("birth_date"):
            values["birth_date"] = None
        return values


CATALOG_PAGES = {
    "facultes": {"title": "Facultés", "subtitle": "Créer et gérer les facultés de l'Université", "fields": [
        ("code", "Code"), ("name", "Nom de la faculté"), ("description", "Description"), ("status", "Statut")], "columns": ["code", "name", "description", "status"]},
    "departements": {"title": "Départements", "subtitle": "Rattacher les départements à une faculté", "fields": [
        ("code", "Code"), ("name", "Nom du département"), ("faculty_code", "Code de la faculté"), ("description", "Description"), ("status", "Statut")], "columns": ["code", "name", "faculty_code", "status"]},
    "filieres": {"title": "Filières", "subtitle": "Gérer les parcours de formation", "fields": [
        ("code", "Code"), ("name", "Nom de la filière"), ("department_code", "Code du département"), ("description", "Description"), ("status", "Statut")], "columns": ["code", "name", "department_code", "status"]},
    "niveaux": {"title": "Niveaux d'études", "subtitle": "Définir les niveaux et leur ordre académique", "fields": [
        ("code", "Code"), ("name", "Libellé du niveau"), ("rank", "Ordre numérique"), ("description", "Description"), ("status", "Statut")], "columns": ["code", "name", "rank", "status"]},
    "annees-academiques": {"title": "Années académiques", "subtitle": "Ouvrir et suivre les années universitaires", "fields": [
        ("year_label", "Année (ex. 2026-2027)"), ("start_date", "Date de début (AAAA-MM-JJ)"), ("end_date", "Date de fin (AAAA-MM-JJ)"), ("status", "Statut")], "columns": ["year_label", "start_date", "end_date", "status"]},
    "enseignants": {"title": "Enseignants", "subtitle": "Gérer les dossiers et les spécialités des enseignants", "fields": [
        ("employee_number", "Matricule / identifiant"), ("last_name", "Nom"), ("first_name", "Prénom(s)"), ("specialty", "Spécialité"), ("email", "Courriel"), ("phone", "Téléphone"), ("status", "Statut")], "columns": ["employee_number", "last_name", "first_name", "specialty", "phone", "status"]},
    "ue": {"title": "Unités d'enseignement", "subtitle": "Définir les UE, crédits, coefficients et semestres", "fields": [
        ("code", "Code UE"), ("title", "Intitulé"), ("credits", "Crédits"), ("coefficient", "Coefficient"), ("semester", "Semestre"), ("program_code", "Code de la filière"), ("level_code", "Code du niveau"), ("status", "Statut")], "columns": ["code", "title", "credits", "coefficient", "semester", "program_code", "level_code", "status"]},
    "cours": {"title": "Cours et matières", "subtitle": "Rattacher les cours aux UE et aux enseignants", "fields": [
        ("code", "Code du cours"), ("title", "Intitulé du cours"), ("coefficient", "Coefficient"), ("ue_code", "Code UE"), ("teacher_number", "Matricule enseignant (facultatif)"), ("status", "Statut")], "columns": ["code", "title", "coefficient", "ue_code", "teacher_number", "status"]},
    "inscriptions": {"title": "Inscriptions", "subtitle": "Inscrire les étudiants dans une filière, un niveau et une année", "fields": [
        ("student_matricule", "Matricule étudiant"), ("program_code", "Code de la filière"), ("level_code", "Code du niveau"), ("academic_year", "Année académique"), ("registration_type", "Type d'inscription"), ("status", "Statut")], "columns": ["student_matricule", "program_code", "level_code", "academic_year", "registration_type", "status"]},
}

STATUS_OPTIONS = ["actif", "inactif", "en attente", "validée", "prévue", "clôturée"]

class CatalogDialog(QDialog):
    def __init__(self, page_config, parent=None, item=None):
        super().__init__(parent)
        self.setWindowTitle("Modifier un enregistrement" if item else "Nouvel enregistrement")
        self.setMinimumWidth(470)
        self.fields = {}
        form = QFormLayout(self)
        for key, label in page_config["fields"]:
            if key == "status":
                widget = QComboBox()
                widget.addItems(STATUS_OPTIONS)
            else:
                widget = QLineEdit()
                if key in ("description",):
                    widget.setPlaceholderText("Facultatif")
            self.fields[key] = widget
            form.addRow(label, widget)
        if item:
            for key, widget in self.fields.items():
                value = item.get(key, "")
                if isinstance(widget, QComboBox):
                    widget.setCurrentText(str(value or "actif"))
                else:
                    widget.setText(str(value if value is not None else ""))
        else:
            for key, widget in self.fields.items():
                if key == "status" and isinstance(widget, QComboBox):
                    widget.setCurrentText("actif")
        buttons = QHBoxLayout()
        cancel = QPushButton("Annuler")
        cancel.setObjectName("secondary")
        save = QPushButton("Enregistrer")
        cancel.clicked.connect(self.reject)
        save.clicked.connect(self.accept)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        form.addRow(buttons)

    def values(self):
        return {key: (widget.currentText() if isinstance(widget, QComboBox) else widget.text().strip())
                for key, widget in self.fields.items()}


class ImportDialog(QDialog):
    def __init__(self, api, entity, title, parent=None):
        super().__init__(parent)
        self.api = api
        self.entity = entity
        self.file_path = ""
        self.setWindowTitle(f"Importer — {title}")
        self.setMinimumSize(650, 480)
        root = QVBoxLayout(self)
        heading = QLabel(f"Importer des données — {title}")
        heading.setObjectName("title")
        heading.setWordWrap(True)
        explanation = QLabel("Formats acceptés : CSV (UTF-8, séparateur ; ou ,) et Excel .xlsx. L'aperçu vérifie les colonnes, les champs obligatoires, les doublons et les références avant tout enregistrement.")
        explanation.setObjectName("muted")
        explanation.setWordWrap(True)
        root.addWidget(heading)
        root.addWidget(explanation)
        file_row = QHBoxLayout()
        self.file_label = QLabel("Aucun fichier sélectionné")
        self.file_label.setObjectName("muted")
        self.file_label.setWordWrap(True)
        browse = QPushButton("Choisir un fichier…")
        browse.clicked.connect(self.browse)
        file_row.addWidget(self.file_label, 1)
        file_row.addWidget(browse)
        root.addLayout(file_row)
        self.report = QTextEdit()
        self.report.setReadOnly(True)
        self.report.setPlaceholderText("Le résultat de l'analyse apparaîtra ici.")
        root.addWidget(self.report, 1)
        buttons = QHBoxLayout()
        self.preview_button = QPushButton("Analyser le fichier")
        self.preview_button.setObjectName("secondary")
        self.preview_button.clicked.connect(self.preview)
        self.import_button = QPushButton("Importer les données")
        self.import_button.setEnabled(False)
        self.import_button.clicked.connect(self.commit)
        close = QPushButton("Fermer")
        close.setObjectName("secondary")
        close.clicked.connect(self.reject)
        buttons.addWidget(self.preview_button)
        buttons.addWidget(self.import_button)
        buttons.addStretch()
        buttons.addWidget(close)
        root.addLayout(buttons)
        self.preview_result = None

    def browse(self):
        path, _ = QFileDialog.getOpenFileName(self, "Sélectionner le fichier", "", "Fichiers de données (*.csv *.xlsx)")
        if path:
            self.file_path = path
            self.file_label.setText(path)
            self.import_button.setEnabled(False)
            self.preview_result = None
            self.report.clear()

    def _render_report(self, result):
        lines = [
            f"Entité : {result.get('entity', self.entity)}",
            f"Lignes détectées : {result.get('total_lignes', 0)}",
            f"Lignes valides : {result.get('lignes_valides', 0)}",
            f"Doublons qui seront ignorés : {result.get('doublons_ignores', 0)}",
            f"Erreurs : {result.get('erreurs', 0)}",
        ]
        errors = result.get("details_erreurs", [])
        if errors:
            lines += ["", "Détail des erreurs :"]
            lines += [f"Ligne {item.get('ligne')}: {item.get('erreur')}" for item in errors[:40]]
            if len(errors) > 40:
                lines.append(f"… et {len(errors) - 40} autre(s) erreur(s).")
        if result.get("message"):
            lines += ["", result["message"]]
        self.report.setPlainText("\n".join(lines))

    def preview(self):
        if not self.file_path:
            QMessageBox.information(self, "Fichier requis", "Choisissez un fichier CSV ou Excel.")
            return
        try:
            result = self.api.import_file(self.entity, self.file_path, dry_run=True)
            self.preview_result = result
            self._render_report(result)
            can_commit = result.get("lignes_valides", 0) > 0 and result.get("erreurs", 0) == 0
            self.import_button.setEnabled(can_commit)
            if result.get("erreurs", 0):
                QMessageBox.warning(self, "Corrections nécessaires", "Des erreurs ont été détectées. Corrigez le fichier puis relancez l'analyse. Aucun enregistrement n'a été modifié.")
            elif result.get("lignes_valides", 0) == 0:
                QMessageBox.information(self, "Aucune donnée", "Aucune nouvelle ligne à importer.")
        except Exception as exc:
            self.import_button.setEnabled(False)
            QMessageBox.warning(self, "Analyse impossible", str(exc))

    def commit(self):
        if not self.preview_result or not self.file_path:
            return
        if QMessageBox.question(self, "Confirmer l'import", "Confirmez-vous l'import des lignes valides dans la base de données ?") != QMessageBox.Yes:
            return
        try:
            result = self.api.import_file(self.entity, self.file_path, dry_run=False)
            self._render_report(result)
            if result.get("import_effectue"):
                QMessageBox.information(self, "Import terminé", result.get("message", "Import effectué."))
                self.accept()
            else:
                self.import_button.setEnabled(False)
                QMessageBox.warning(self, "Import annulé", result.get("message", "L'import n'a pas été effectué."))
        except Exception as exc:
            QMessageBox.warning(self, "Import impossible", str(exc))



class CatalogPage(QWidget):
    def __init__(self, api, entity, config, can_write):
        super().__init__()
        self.api = api
        self.entity = entity
        self.config = config
        self.can_write = can_write
        self.rows = []
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 25, 28, 25)
        root.setSpacing(14)
        title = QLabel(config["title"])
        title.setObjectName("title")
        subtitle = QLabel(config["subtitle"])
        subtitle.setObjectName("muted")
        root.addWidget(title)
        root.addWidget(subtitle)
        bar = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Rechercher dans cette rubrique…")
        self.search.returnPressed.connect(self.refresh)
        search_btn = QPushButton("Rechercher")
        search_btn.clicked.connect(self.refresh)
        bar.addWidget(self.search, 1)
        bar.addWidget(search_btn)
        if can_write:
            add = QPushButton("+ Ajouter")
            add.clicked.connect(self.add_item)
            bar.addWidget(add)
            import_btn = QPushButton("Importer CSV / Excel")
            import_btn.setObjectName("secondary")
            import_btn.clicked.connect(self.import_items)
            bar.addWidget(import_btn)
            template_btn = QPushButton("Modèle Excel")
            template_btn.setObjectName("secondary")
            template_btn.clicked.connect(self.download_template)
            bar.addWidget(template_btn)
        root.addLayout(bar)
        self.table = QTableWidget(0, len(config["columns"]))
        labels = [dict(config["fields"]).get(key, key) for key in config["columns"]]
        self.table.setHorizontalHeaderLabels(labels)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        if self.can_write:
            self.table.doubleClicked.connect(self.edit_item)
        root.addWidget(self.table, 1)
        if can_write:
            actions = QHBoxLayout()
            edit = QPushButton("Modifier")
            edit.setObjectName("secondary")
            edit.clicked.connect(self.edit_item)
            archive = QPushButton("Archiver")
            archive.setObjectName("danger")
            archive.clicked.connect(self.archive_item)
            actions.addWidget(edit)
            actions.addWidget(archive)
            actions.addStretch()
            root.addLayout(actions)
        self.refresh()

    def import_items(self):
        dialog = ImportDialog(self.api, self.entity, self.config["title"], self)
        if dialog.exec():
            self.refresh()

    def download_template(self):
        path, _ = QFileDialog.getSaveFileName(self, "Enregistrer le modèle Excel", f"modele_import_{self.entity}.xlsx", "Classeur Excel (*.xlsx);;Fichier CSV (*.csv)")
        if not path:
            return
        file_format = "csv" if path.lower().endswith(".csv") else "xlsx"
        if not path.lower().endswith((".csv", ".xlsx")):
            path += ".xlsx"
            file_format = "xlsx"
        try:
            self.api.download_import_template(self.entity, path, file_format)
            QMessageBox.information(self, "Modèle prêt", f"Modèle enregistré :\n{path}")
        except Exception as exc:
            QMessageBox.warning(self, "Téléchargement impossible", str(exc))

    def refresh(self):
        try:
            self.rows = self.api.call("GET", f"/catalog/{self.entity}", params={"q": self.search.text()})
            self.table.setRowCount(len(self.rows))
            for row_index, item in enumerate(self.rows):
                for col_index, key in enumerate(self.config["columns"]):
                    value = item.get(key, "")
                    self.table.setItem(row_index, col_index, QTableWidgetItem(str(value if value is not None else "")))
            self.table.resizeRowsToContents()
        except Exception as exc:
            QMessageBox.warning(self, self.config["title"], str(exc))

    def selected(self):
        row = self.table.currentRow()
        return self.rows[row] if 0 <= row < len(self.rows) else None

    def add_item(self):
        dialog = CatalogDialog(self.config, self)
        if dialog.exec():
            try:
                self.api.call("POST", f"/catalog/{self.entity}", json=dialog.values())
                self.refresh()
            except Exception as exc:
                QMessageBox.warning(self, "Enregistrement impossible", str(exc))

    def edit_item(self):
        item = self.selected()
        if not item:
            QMessageBox.information(self, "Sélection", "Sélectionnez un enregistrement dans le tableau.")
            return
        dialog = CatalogDialog(self.config, self, item)
        if dialog.exec():
            try:
                self.api.call("PUT", f"/catalog/{self.entity}/{item['id']}", json=dialog.values())
                self.refresh()
            except Exception as exc:
                QMessageBox.warning(self, "Modification impossible", str(exc))

    def archive_item(self):
        item = self.selected()
        if not item:
            QMessageBox.information(self, "Sélection", "Sélectionnez un enregistrement dans le tableau.")
            return
        label = item.get("name") or item.get("title") or item.get("year_label") or item.get("last_name") or item.get("code")
        if QMessageBox.question(self, "Confirmation", f"Archiver « {label} » ?") != QMessageBox.Yes:
            return
        try:
            self.api.call("POST", f"/catalog/{self.entity}/{item['id']}/archive")
            self.refresh()
        except Exception as exc:
            QMessageBox.warning(self, "Archivage impossible", str(exc))


class StudentPage(QWidget):
    def __init__(self, api, refresh_dashboard, can_write=True):
        super().__init__()
        self.api = api
        self.refresh_dashboard = refresh_dashboard
        self.can_write = can_write
        self.rows = []
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 25, 28, 25)
        root.setSpacing(14)
        title = QLabel("Gestion des étudiants")
        title.setObjectName("title")
        subtitle = QLabel("Créer, rechercher, modifier et archiver les dossiers étudiants")
        subtitle.setObjectName("muted")
        root.addWidget(title)
        root.addWidget(subtitle)
        bar = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Rechercher par matricule ou nom…")
        self.search.returnPressed.connect(self.refresh)
        search_btn = QPushButton("Rechercher")
        search_btn.clicked.connect(self.refresh)
        bar.addWidget(self.search, 1)
        bar.addWidget(search_btn)
        if self.can_write:
            add = QPushButton("+ Nouvel étudiant")
            add.clicked.connect(self.add_student)
            bar.addWidget(add)
            import_btn = QPushButton("Importer CSV / Excel")
            import_btn.setObjectName("secondary")
            import_btn.clicked.connect(self.import_students)
            bar.addWidget(import_btn)
            template_btn = QPushButton("Modèle Excel")
            template_btn.setObjectName("secondary")
            template_btn.clicked.connect(self.download_template)
            bar.addWidget(template_btn)
        root.addLayout(bar)
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["Matricule", "Nom", "Prénom(s)", "Filière", "Niveau", "Téléphone", "Statut"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        if self.can_write:
            self.table.doubleClicked.connect(self.edit_student)
        root.addWidget(self.table, 1)
        if self.can_write:
            actions = QHBoxLayout()
            edit = QPushButton("Modifier")
            edit.setObjectName("secondary")
            edit.clicked.connect(self.edit_student)
            archive = QPushButton("Archiver")
            archive.setObjectName("danger")
            archive.clicked.connect(self.archive_student)
            actions.addWidget(edit)
            actions.addWidget(archive)
            actions.addStretch()
            root.addLayout(actions)
        self.refresh()

    def import_students(self):
        dialog = ImportDialog(self.api, "etudiants", "Étudiants", self)
        if dialog.exec():
            self.refresh()
            self.refresh_dashboard()

    def download_template(self):
        path, _ = QFileDialog.getSaveFileName(self, "Enregistrer le modèle Excel", "modele_import_etudiants.xlsx", "Classeur Excel (*.xlsx);;Fichier CSV (*.csv)")
        if not path:
            return
        file_format = "csv" if path.lower().endswith(".csv") else "xlsx"
        if not path.lower().endswith((".csv", ".xlsx")):
            path += ".xlsx"
            file_format = "xlsx"
        try:
            self.api.download_import_template("etudiants", path, file_format)
            QMessageBox.information(self, "Modèle prêt", f"Modèle enregistré :\n{path}")
        except Exception as exc:
            QMessageBox.warning(self, "Téléchargement impossible", str(exc))

    def refresh(self):
        try:
            self.rows = self.api.call("GET", "/students", params={"q": self.search.text()})
            self.table.setRowCount(len(self.rows))
            keys = ["matricule", "last_name", "first_name", "program", "level", "phone", "status"]
            for r, item in enumerate(self.rows):
                for c, key in enumerate(keys):
                    self.table.setItem(r, c, QTableWidgetItem(str(item.get(key, "") or "")))
            self.table.resizeColumnsToContents()
        except Exception as exc:
            QMessageBox.warning(self, "Étudiants", str(exc))

    def selected(self):
        row = self.table.currentRow()
        return self.rows[row] if 0 <= row < len(self.rows) else None

    def add_student(self):
        dialog = StudentDialog(self)
        if dialog.exec():
            try:
                self.api.call("POST", "/students", json=dialog.values())
                self.refresh()
                self.refresh_dashboard()
            except Exception as exc:
                QMessageBox.warning(self, "Création impossible", str(exc))

    def edit_student(self):
        item = self.selected()
        if not item:
            QMessageBox.information(self, "Sélection", "Sélectionnez un étudiant.")
            return
        dialog = StudentDialog(self, item)
        if dialog.exec():
            try:
                self.api.call("PUT", f"/students/{item['id']}", json=dialog.values())
                self.refresh()
            except Exception as exc:
                QMessageBox.warning(self, "Modification impossible", str(exc))

    def archive_student(self):
        item = self.selected()
        if not item:
            QMessageBox.information(self, "Sélection", "Sélectionnez un étudiant.")
            return
        if QMessageBox.question(self, "Confirmation", f"Archiver le dossier {item['matricule']} ?") != QMessageBox.Yes:
            return
        try:
            self.api.call("POST", f"/students/{item['id']}/archive")
            self.refresh()
            self.refresh_dashboard()
        except Exception as exc:
            QMessageBox.warning(self, "Archivage impossible", str(exc))


class DashboardPage(QWidget):
    def __init__(self, api):
        super().__init__()
        self.api = api
        self.labels = {}
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 25, 28, 25)
        root.setSpacing(16)
        title = QLabel("Tableau de bord")
        title.setObjectName("title")
        subtitle = QLabel("Vue générale de l'activité de la scolarité")
        subtitle.setObjectName("muted")
        root.addWidget(title)
        root.addWidget(subtitle)
        cards = QHBoxLayout()
        for key, label in [
            ("students", "Étudiants enregistrés"),
            ("active_students", "Dossiers actifs"),
            ("users", "Comptes utilisateurs"),
            ("enrollments", "Inscriptions")
        ]:
            card = QFrame()
            card.setObjectName("card")
            cv = QVBoxLayout(card)
            value = QLabel("—")
            value.setStyleSheet("font-size:28px;font-weight:700;color:#183b66;")
            caption = QLabel(label)
            caption.setObjectName("muted")
            cv.addWidget(value)
            cv.addWidget(caption)
            cards.addWidget(card)
            self.labels[key] = value
        root.addLayout(cards)
        info = QFrame()
        info.setObjectName("card")
        iv = QVBoxLayout(info)
        heading = QLabel("Bienvenue dans SCOLARITÉ UMa")
        heading.setStyleSheet("font-size:18px;font-weight:700;")
        iv.addWidget(heading)
        iv.addWidget(QLabel("Utilisez le menu latéral pour gérer les référentiels, les inscriptions, les évaluations et les résultats selon vos autorisations."))
        root.addWidget(info)
        root.addStretch()
        self.refresh()

    def refresh(self):
        try:
            data = self.api.call("GET", "/dashboard")
            for key, label in self.labels.items():
                label.setText(str(data.get(key, 0)))
        except Exception as exc:
            QMessageBox.warning(self, "Tableau de bord", str(exc))


PLACEHOLDERS = {
    "assessments": ("Évaluations", "Paramétrage des évaluations", "Créer des évaluations rattachées à un cours et une session."),
    "utilisateurs": ("Utilisateurs et rôles", "Gestion des comptes", "Création et désactivation des comptes, attribution des rôles et permissions détaillées."),
    "emplois-temps": ("Emplois du temps", "Planification des séances", "Calendriers par filière et niveau, salles, enseignants et détection des chevauchements."),
    "examens": ("Sessions et examens", "Organisation des évaluations", "Création des sessions, types d'épreuves, périodes et rattachement aux cours."),
    "saisie-notes": ("Saisie des notes", "Évaluations et notes", "Saisie des notes par cours et étudiant, import contrôlé et suivi des notes manquantes."),
    "validation-notes": ("Contrôle et validation des notes", "Contrôle pédagogique", "Vérification des notes, verrouillage après validation et demandes de correction justifiées."),
    "deliberations": ("Délibérations", "Décisions académiques", "Préparation des délibérations, décisions, procès-verbaux et historique des validations."),
    "calcul-moyennes": ("Calcul des moyennes", "Règles de calcul", "Calcul pondéré des cours, UE, semestres et années selon les règles paramétrées de l'établissement."),
    "resultats": ("Consultation des résultats", "Résultats académiques", "Consultation des résultats par étudiant, filière, niveau et année universitaire."),
    "publication": ("Publication des résultats", "Mise à disposition des résultats", "Publication après validation et verrouillage, avec visibilité selon le profil connecté."),
    "documents": ("Documents administratifs", "Éditions PDF", "Génération des relevés de notes, certificats de scolarité, attestations, listes et procès-verbaux."),
    "statistiques": ("Statistiques et rapports", "Pilotage universitaire", "Effectifs, taux de réussite, moyennes, évolutions et exports pour la Direction."),
    "historique": ("Historique des opérations", "Traçabilité", "Consultation filtrée des actions sensibles : auteur, date, entité et nature de l'opération."),
    "parametres": ("Paramètres", "Configuration de l'établissement", "Paramétrage des seuils, coefficients, règles de validation, pièces requises et préférences de fonctionnement.")
}

class PlaceholderPage(QWidget):
    def __init__(self, title, subtitle, description):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 25, 28, 25)
        root.setSpacing(16)
        heading = QLabel(title)
        heading.setObjectName("title")
        sub = QLabel(subtitle)
        sub.setObjectName("muted")
        root.addWidget(heading)
        root.addWidget(sub)
        card = QFrame()
        card.setObjectName("card")
        layout = QVBoxLayout(card)
        status = QLabel("MODULE EN COURS DE DÉVELOPPEMENT")
        status.setStyleSheet("font-size:11px;font-weight:700;color:#8a5a12;background:#fff4db;padding:8px;border-radius:5px;")
        layout.addWidget(status)
        text = QLabel(description)
        text.setWordWrap(True)
        text.setStyleSheet("font-size:14px;")
        layout.addWidget(text)
        note = QLabel("Cette rubrique est déjà intégrée à la navigation, mais ses opérations ne sont pas encore activées. Les données ne sont pas simulées.")
        note.setObjectName("muted")
        note.setWordWrap(True)
        layout.addWidget(note)
        root.addWidget(card)
        root.addStretch()


NAVIGATION = [
    ("ACCUEIL", [("Tableau de bord", "dashboard")]),
    ("ADMINISTRATION", [("Utilisateurs et rôles", "utilisateurs")]),
    ("STRUCTURE UNIVERSITAIRE", [("Facultés", "facultes"), ("Départements", "departements"), ("Filières", "filieres"), ("Niveaux", "niveaux"), ("Années académiques", "annees-academiques")]),
    ("SCOLARITÉ", [("Étudiants", "etudiants"), ("Inscriptions", "inscriptions")]),
    ("PÉDAGOGIE", [("Enseignants", "enseignants"), ("Unités d'enseignement", "ue"), ("Cours et matières", "cours"), ("Emplois du temps", "emplois-temps")]),
    ("EXAMENS ET NOTES", [("Sessions et examens", "examens"), ("Évaluations", "assessments"), ("Saisie des notes", "saisie-notes"), ("Contrôle / validation", "validation-notes"), ("Délibérations", "deliberations")]),
    ("RÉSULTATS", [("Calcul des moyennes", "calcul-moyennes"), ("Consultation des résultats", "resultats"), ("Publication", "publication")]),
    ("DOCUMENTS", [("Documents PDF", "documents")]),
    ("PILOTAGE", [("Statistiques et rapports", "statistiques"), ("Historique", "historique")]),
    ("SYSTÈME", [("Paramètres", "parametres")]),
]


OPERATIONAL_PAGES = {
 "utilisateurs": {"title":"Utilisateurs et rôles","path":"/users","fields":[("username","Identifiant"),("full_name","Nom complet"),("password","Mot de passe initial"),("role","Rôle (admin/scolarite/responsable_pedagogique/enseignant/etudiant/direction)")]},
 "examens": {"title":"Sessions d'examens","path":"/exam-sessions","fields":[("code","Code"),("title","Intitulé"),("academic_year","Année académique"),("semester","Semestre"),("starts_on","Date début AAAA-MM-JJ"),("ends_on","Date fin AAAA-MM-JJ")]},
 "assessments": {"title":"Évaluations","path":"/assessments","fields":[("code","Code"),("title","Intitulé"),("course_code","Code cours"),("session_code","Code session"),("weight","Pondération"),("max_score","Barème maximum")]},
 "saisie-notes": {"title":"Saisie des notes","path":"/grades","fields":[("assessment_code","Code évaluation"),("student_matricule","Matricule étudiant"),("score","Note") ]},
 "validation-notes": {"title":"Contrôle et validation","path":"/grades","fields":[]},
 "deliberations": {"title":"Délibérations / résultats UE","path":"/results","fields":[]},
 "calcul-moyennes": {"title":"Calcul des moyennes","path":"/results","fields":[]},
 "resultats": {"title":"Résultats publiés","path":"/results","fields":[]},
 "publication": {"title":"Publication des notes","path":"/grades","fields":[]},
 "emplois-temps": {"title":"Emplois du temps","path":"/timetable","fields":[("course_code","Code cours"),("academic_year","Année académique"),("level_code","Code niveau"),("weekday","Jour (1=lundi)"),("starts_at","Début HH:MM"),("ends_at","Fin HH:MM"),("room","Salle"),("teacher_number","Matricule enseignant")]},
 "historique": {"title":"Historique des opérations","path":"/audit","fields":[]},
 "parametres": {"title":"Paramètres académiques","path":"/settings","fields":[("passing_grade","Seuil de validation"),("max_grade","Note maximale"),("semester_credits","Crédits semestre"),("academic_system","Système académique")]},
 "documents": {"title":"Documents et relevés PDF","path":"/results","fields":[]},
 "statistiques": {"title":"Statistiques et rapports","path":"/dashboard","fields":[]},
}

class OperationalPage(QWidget):
    def __init__(self, api, key, config, role):
        super().__init__(); self.api=api; self.key=key; self.config=config; self.role=role
        root=QVBoxLayout(self); root.setContentsMargins(26,22,26,22); root.setSpacing(12)
        title=QLabel(config["title"]); title.setObjectName("title"); root.addWidget(title)
        self.note=QLabel("Données réelles enregistrées dans la base de données."); self.note.setObjectName("muted"); root.addWidget(self.note)
        bar=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText("Filtrer les lignes affichées…"); self.search.textChanged.connect(self.filter_rows); bar.addWidget(self.search,1)
        self.add_btn=QPushButton("Nouvel enregistrement"); self.add_btn.clicked.connect(self.create); bar.addWidget(self.add_btn)
        self.action_btn=QPushButton("Valider / publier"); self.action_btn.setObjectName("secondary"); self.action_btn.clicked.connect(self.action); bar.addWidget(self.action_btn)
        self.pdf_btn=QPushButton("Télécharger mon relevé PDF"); self.pdf_btn.clicked.connect(self.download_pdf); bar.addWidget(self.pdf_btn)
        if self.key != "documents": self.pdf_btn.hide()
        root.addLayout(bar); self.table=QTableWidget(); self.table.setAlternatingRowColors(True); self.table.setEditTriggers(QTableWidget.NoEditTriggers); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); root.addWidget(self.table,1)
        if not config["fields"]: self.add_btn.hide()
        if key not in ("validation-notes","publication"): self.action_btn.hide()
        self.refresh()
    def refresh(self):
        try:
            data=self.api.call("GET",self.config["path"]); self.rows=data if isinstance(data,list) else ([{"paramètre":k,"valeur":v} for k,v in data.items()] if isinstance(data,dict) else [])
            if self.key=="statistiques": self.rows=[{"indicateur":k,"valeur":v} for k,v in data.items()]
            cols=list(self.rows[0].keys()) if self.rows else ([f[0] for f in self.config["fields"]] or ["Information"])
            self.table.clear(); self.table.setColumnCount(len(cols)); self.table.setHorizontalHeaderLabels(cols); self.table.setRowCount(len(self.rows))
            for r,row in enumerate(self.rows):
                for c,col in enumerate(cols): self.table.setItem(r,c,QTableWidgetItem(str(row.get(col,""))))
        except Exception as e: self.note.setText("Chargement impossible : "+str(e))
    def filter_rows(self,text):
        for r in range(self.table.rowCount()):
            self.table.setRowHidden(r, bool(text) and not any(text.lower() in (self.table.item(r,c).text().lower() if self.table.item(r,c) else "") for c in range(self.table.columnCount())))
    def create(self):
        dialog=QDialog(self); dialog.setWindowTitle("Nouvel enregistrement — "+self.config["title"]); form=QFormLayout(dialog); widgets={}
        for key,label in self.config["fields"]:
            w=QLineEdit(); w.setPlaceholderText(label)
            if key == "password": w.setEchoMode(QLineEdit.Password)
            widgets[key]=w; form.addRow(label,w)
        buttons=QHBoxLayout(); ok=QPushButton("Enregistrer"); cancel=QPushButton("Annuler"); cancel.clicked.connect(dialog.reject); ok.clicked.connect(dialog.accept); buttons.addWidget(cancel); buttons.addWidget(ok); form.addRow(buttons)
        if dialog.exec()!=QDialog.Accepted: return
        payload={k:w.text().strip() for k,w in widgets.items()}
        try:
            if self.key=="utilisateurs": self.api.call("POST",self.config["path"],json=payload)
            elif self.key=="parametres": self.api.call("PUT",self.config["path"],json=payload)
            elif self.key=="saisie-notes": payload["score"]=float(payload["score"]); self.api.call("POST",self.config["path"],json=payload)
            elif self.key=="emplois-temps": payload["weekday"]=int(payload["weekday"]); self.api.call("POST",self.config["path"],json=payload)
            elif self.key=="assessments": payload["weight"]=float(payload["weight"]); payload["max_score"]=float(payload["max_score"]); self.api.call("POST",self.config["path"],json=payload)
            else: self.api.call("POST",self.config["path"],json=payload)
            self.refresh(); QMessageBox.information(self,"Enregistrement","Opération effectuée.")
        except Exception as e: QMessageBox.warning(self,"Opération impossible",str(e))
    def download_pdf(self):
        matricule,ok=QInputDialog.getText(self,"Relevé PDF","Matricule étudiant (laisser vide pour votre compte étudiant) :")
        if not ok: return
        if not matricule.strip() and self.role=="etudiant": matricule=self.api.call("GET","/auth/me").get("username","")
        if not matricule.strip(): return
        path,_=QFileDialog.getSaveFileName(self,"Enregistrer le relevé",f"releve_{matricule}.pdf","PDF (*.pdf)")
        if not path: return
        try:
            response=requests.get(API_URL+f"/students/{matricule.strip()}/transcript.pdf",headers={"Authorization":f"Bearer {self.api.token}"},timeout=60)
            if response.status_code>=400: raise RuntimeError(response.text[:300])
            with open(path,"wb") as f: f.write(response.content)
            QMessageBox.information(self,"Document","Relevé PDF enregistré.")
        except Exception as exc: QMessageBox.warning(self,"Export PDF",str(exc))
    def action(self):
        code,ok=QInputDialog.getText(self,"Validation","Code de l'évaluation :")
        if not ok or not code.strip(): return
        endpoint="/grades/validate" if self.key=="validation-notes" else "/grades/publish"
        try: result=self.api.call("POST",endpoint,json={"assessment_code":code.strip()}); QMessageBox.information(self,"Opération",result.get("message","Terminé")); self.refresh()
        except Exception as e: QMessageBox.warning(self,"Opération impossible",str(e))

class MainWindow(QMainWindow):
    def __init__(self, api, session):
        super().__init__()
        self.api = api
        self.session = session
        self.pages = {}
        self.setWindowTitle("SCOLARITÉ UMa")
        self.resize(1380, 850)
        base = QWidget()
        self.setCentralWidget(base)
        layout = QHBoxLayout(base)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(255)
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(12, 18, 12, 14)
        side_layout.setSpacing(5)
        logo = QLabel("SCOLARITÉ UMa")
        logo.setStyleSheet("font-size:19px;font-weight:700;color:white;padding:4px 10px;")
        side_layout.addWidget(logo)
        identity = QLabel(f"{session.get('full_name', 'Utilisateur')}\n{session.get('role', '')}")
        identity.setStyleSheet("color:#b8c8dc;padding:8px 10px 12px 10px;")
        side_layout.addWidget(identity)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { background:transparent; } QScrollBar:vertical { width:7px; background:#122945; } QScrollBar::handle:vertical { background:#486786; border-radius:3px; }")
        menu_content = QWidget()
        menu_content.setStyleSheet("background:#122945;")
        menu_layout = QVBoxLayout(menu_content)
        menu_layout.setContentsMargins(0, 0, 0, 0)
        menu_layout.setSpacing(2)
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_buttons = {}
        role = session.get("role", "")
        role_pages = {
            "admin": None,
            "scolarite": {"dashboard","etudiants","inscriptions","annees-academiques","examens","assessments","saisie-notes","validation-notes","resultats","publication","documents","statistiques"},
            "responsable_pedagogique": {"dashboard","facultes","departements","filieres","niveaux","enseignants","ue","cours","emplois-temps","examens","assessments","saisie-notes","validation-notes","deliberations","calcul-moyennes","resultats","statistiques"},
            "enseignant": {"dashboard","emplois-temps","saisie-notes"},
            "etudiant": {"dashboard","emplois-temps","resultats","publication","documents"},
            "direction": {"dashboard","statistiques","resultats"},
        }
        allowed = role_pages.get(role, {"dashboard"})
        for group_title, entries in NAVIGATION:
            visible = [(label,key) for label,key in entries if allowed is None or key in allowed]
            if not visible: continue
            group_label = QLabel(group_title)
            group_label.setObjectName("navheading")
            menu_layout.addWidget(group_label)
            for label, key in visible:
                button = QPushButton(label)
                button.setObjectName("nav")
                button.setCheckable(True)
                button.clicked.connect(lambda checked=False, page_key=key: self.show_page(page_key))
                self.nav_group.addButton(button)
                self.nav_buttons[key] = button
                menu_layout.addWidget(button)
        menu_layout.addStretch()
        scroll.setWidget(menu_content)
        side_layout.addWidget(scroll, 1)
        logout = QPushButton("Déconnexion")
        logout.clicked.connect(self.logout)
        side_layout.addWidget(logout)

        self.stack = QStackedWidget()
        self.dashboard_page = DashboardPage(self.api)
        self.pages["dashboard"] = self.dashboard_page
        self.stack.addWidget(self.dashboard_page)
        self.student_page = StudentPage(self.api, self.dashboard_page.refresh,
                                        can_write=session.get("role") in ("admin", "scolarite"))
        self.pages["etudiants"] = self.student_page
        self.stack.addWidget(self.student_page)
        catalog_writers = {
            "facultes": ("admin", "responsable_pedagogique"),
            "departements": ("admin", "responsable_pedagogique"),
            "filieres": ("admin", "responsable_pedagogique"),
            "niveaux": ("admin", "responsable_pedagogique"),
            "annees-academiques": ("admin", "scolarite"),
            "enseignants": ("admin", "responsable_pedagogique"),
            "ue": ("admin", "responsable_pedagogique"),
            "cours": ("admin", "responsable_pedagogique"),
            "inscriptions": ("admin", "scolarite"),
        }
        for entity, config in CATALOG_PAGES.items():
            can_write = session.get("role") in catalog_writers[entity]
            page = CatalogPage(self.api, entity, config, can_write)
            self.pages[entity] = page
            self.stack.addWidget(page)
        for key, (title, subtitle, description) in PLACEHOLDERS.items():
            if key in OPERATIONAL_PAGES:
                page = OperationalPage(self.api, key, OPERATIONAL_PAGES[key], session.get("role", ""))
            else:
                page = PlaceholderPage(title, subtitle, description)
            self.pages[key] = page
            self.stack.addWidget(page)

        layout.addWidget(sidebar)
        layout.addWidget(self.stack, 1)
        self.nav_buttons["dashboard"].setChecked(True)
        self.show_page("dashboard")

    def show_page(self, key):
        page = self.pages.get(key)
        if page:
            self.stack.setCurrentWidget(page)
            if key == "dashboard":
                self.dashboard_page.refresh()
            elif key == "etudiants":
                self.student_page.refresh()
            elif key in CATALOG_PAGES:
                page.refresh()
            elif key in OPERATIONAL_PAGES:
                page.refresh()

    def logout(self):
        self.login = LoginWindow(Api())
        self.login.show()
        self.close()


def main():
    app = QApplication(sys.argv)
    try:
        ensure_local_server()
    except Exception as exc:
        QMessageBox.critical(None, "Démarrage impossible", str(exc))
        raise SystemExit(1)
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE)
    api = Api()
    window = LoginWindow(api)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

# Build with: pyinstaller --noconfirm --clean client/scolarite-uma.spec
from PyInstaller.utils.hooks import collect_submodules
hidden = collect_submodules('PySide6')
a = Analysis(['client/main.py'], pathex=[], binaries=[], datas=[], hiddenimports=hidden, hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, a.binaries, a.datas, [], name='scolarite-uma', debug=False, bootloader_ignore_signals=False, strip=False, upx=True, console=False)

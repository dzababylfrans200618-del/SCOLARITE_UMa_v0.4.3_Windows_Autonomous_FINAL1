# Correction de l'installation Linux

Le client utilise uniquement Qt Core, Qt GUI et Qt Widgets. Le paquet `PySide6` complet entraînait l'installation de modules Qt additionnels inutilisés, notamment Qt WebEngine (environ 117 Mo dans l'environnement observé).

La dépendance a été remplacée par `PySide6-Essentials`, qui fournit les composants utilisés par l'interface graphique. Le script d'installation utilise également des délais et tentatives réseau plus tolérants.

Depuis la racine du projet :

```bash
./scripts/install-client-linux.sh
```

Si une installation précédente est incomplète, le script réutilise l'environnement virtuel existant. Pour repartir proprement, supprimer uniquement l'environnement du client :

```bash
rm -rf .venv-client
./scripts/install-client-linux.sh
```

Cette suppression ne touche ni aux fichiers du projet ni à la base de données.

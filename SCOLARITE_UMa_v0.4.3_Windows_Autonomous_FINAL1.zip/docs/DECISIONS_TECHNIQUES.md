# Décisions techniques

- Client bureau : PySide6 / Qt 6.
- API métier : FastAPI.
- ORM : SQLAlchemy 2.
- Base cible : PostgreSQL 16.
- Base SQLite autorisée uniquement pour le développement local monoposte.
- Authentification : jetons JWT à durée limitée ; mots de passe hachés avec bcrypt.
- Contrôle d'accès : vérification serveur par rôle.
- Audit : journal des opérations administratives sensibles.
- Installation : environnement Python isolé pour le client ; Docker Compose pour le serveur.

Les décisions métier concernant les règles de notation, les crédits, les délibérations et les pièces d'inscription doivent être confirmées par les autorités compétentes de l'Université avant leur implémentation.

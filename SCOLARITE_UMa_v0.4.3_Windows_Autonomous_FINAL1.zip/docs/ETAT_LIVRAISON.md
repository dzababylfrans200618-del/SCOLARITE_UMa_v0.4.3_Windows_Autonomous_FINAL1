# État de livraison — SCOLARITÉ UMa 0.4.0

## Périmètre TPE
Application desktop Linux avec API FastAPI et base SQLAlchemy (SQLite pour démonstration locale, PostgreSQL possible via DATABASE_URL). La base n'est pas préremplie avec des données institutionnelles : l'administrateur crée les référentiels ou les importe depuis CSV/XLSX.

## Fonctions présentes
- Authentification JWT et contrôle des rôles côté API.
- Tableau de bord et dossiers étudiants (création, recherche, modification, archivage).
- Référentiels CRUD : facultés, départements, filières, niveaux, années académiques, enseignants, UE, cours, inscriptions.
- Import contrôlé CSV/XLSX pour ces dix catégories, modèles téléchargeables, prévalidation, doublons ignorés, rapport d'erreurs.
- Comptes : création/modification/désactivation par administrateur depuis l'écran Utilisateurs.
- Sessions d'examens et évaluations rattachées aux cours.
- Saisie de notes bornées par le barème, liées à un étudiant inscrit à la filière/niveau de l’UE ; un enseignant est limité aux cours qui lui sont affectés.
- Validation et verrouillage des notes après contrôle des notes manquantes pour les étudiants inscrits à la filière/niveau de l’UE, puis publication séparée.
- Calcul de moyennes pondérées par coefficient de cours, moyennes d'UE et agrégation semestrielle pondérée par crédits.
- Emplois du temps avec détection de chevauchement pour un niveau et une année.
- Consultation des résultats publiés, export CSV, relevé PDF individuel.
- Historique des opérations sensibles, paramètres LMD de démonstration.
- Menu filtré selon les rôles : administrateur, scolarité, responsable pédagogique, enseignant, étudiant, direction.

## Hypothèses pédagogiques de démonstration
Les règles suivantes ne sont pas toutes définies par le document de cadrage et restent paramétrables : seuil 10/20, note maximale 20, 30 crédits requis par semestre, moyenne d'UE calculée par coefficients de cours, moyenne semestrielle pondérée par crédits d'UE. La validation du semestre exige le seuil et le nombre minimal de crédits validés. Ces hypothèses doivent être explicitement signalées pendant la soutenance comme paramètres de démonstration, et non comme règlement officiel de l'Université.

## Limites connues
- La gestion des corrections après validation n'a pas encore de workflow d'approbation dédié : les notes validées sont verrouillées.
- Les résultats semestriels sont calculés à partir des évaluations publiées disponibles ; les sessions de rattrapage, compensation détaillée, jury multi-membres et procès-verbal officiel ne sont pas implémentés.
- Les espaces enseignant et étudiant sont filtrés par rôle, mais le rattachement automatique des enseignants à leurs cours et la liaison de compte étudiant à un dossier doivent être complétés pour un usage réel. Pour le scénario étudiant de démonstration, l'identifiant du compte correspond au matricule.
- Les emplois du temps vérifient les chevauchements par niveau ; la détection globale des conflits de salle et d'enseignant devra être renforcée.
- Le PDF fourni est un relevé individuel de démonstration, pas un document officiel certifié.
- Les imports CSV/XLSX couvrent les référentiels et inscriptions, pas les comptes, notes, emplois du temps ni sessions d'examens.
- La génération automatique des attestations et certificats de scolarité n'est pas encore incluse.

## Vérifications de cette livraison
- Compilation Python du client et des modules serveur : réussie.
- Tests du parseur CSV/XLSX : 6 réussis.
- Test d'intégration API sur base SQLite temporaire : création des référentiels, étudiant, inscription, session, évaluation, saisie, validation, publication, calcul de moyenne et détection d'un conflit d'emploi du temps réussis.
- L'environnement de construction ne dispose pas de PySide6 ni des dépendances de sécurité installables hors ligne : le lancement graphique complet et le parcours avec authentification réelle doivent être vérifiés sur Kali Linux après mise à jour des dépendances.

Cette version constitue une démonstration TPE avancée. Elle n'est pas certifiée pour gérer les dossiers officiels d'une université en production.

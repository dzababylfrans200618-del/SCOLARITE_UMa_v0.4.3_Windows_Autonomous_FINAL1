# Évolution SCOLARITÉ UMa — version 0.2.0

## Nouveaux écrans fonctionnels

Le menu latéral est maintenant organisé par domaines : Accueil, Administration, Structure universitaire, Scolarité, Pédagogie, Examens et notes, Résultats, Documents, Pilotage et Système.

Les écrans suivants communiquent réellement avec l'API et la base de données :

- Étudiants : création, recherche, modification et archivage.
- Facultés : création, consultation, modification et archivage.
- Départements : rattachement à une faculté existante.
- Filières : rattachement à un département existant.
- Niveaux : code, libellé et ordre académique.
- Années académiques : libellé, dates et statut.
- Enseignants : matricule, identité, spécialité et coordonnées.
- Unités d'enseignement : crédits, coefficient, semestre, filière et niveau.
- Cours : rattachement à une UE et, facultativement, à un enseignant.
- Inscriptions : étudiant, filière, niveau, année et type d'inscription.

Les opérations de création, modification et archivage sont journalisées. Les codes uniques sont contrôlés. Les relations sont vérifiées côté API et matérialisées par des clés étrangères pour les tables académiques concernées.

## Pages visibles mais pas encore opérationnelles

Les pages Utilisateurs et rôles, Emplois du temps, Sessions et examens, Saisie des notes, Contrôle/validation, Délibérations, Calcul des moyennes, Résultats, Publication, Documents PDF, Statistiques avancées, Historique consultable et Paramètres constituent la navigation cible. Elles affichent un statut « Module en cours de développement » jusqu'à l'implémentation de leurs opérations.

Les règles de calcul des moyennes, crédits, décisions et délibérations doivent être confirmées par l'Université avant leur automatisation.

## Mise à jour d'une installation existante

Cette évolution n'impose pas de supprimer le dossier du projet, l'environnement virtuel client, le fichier `.env` ni la base SQLite/PostgreSQL.

1. Arrêter le serveur API et fermer le client.
2. Faire une copie de sauvegarde de la base avant toute mise à jour.
3. Extraire l'archive dans un dossier temporaire pour accéder au script `scripts/apply-update.sh`.
4. Exécuter le script avec l'archive et le chemin du projet existant : `bash /chemin/temporaire/SCOLARITE_UMa/scripts/apply-update.sh /chemin/SCOLARITE_UMa_v0.2.0.zip /chemin/du/projet-existant`.
5. Le script sauvegarde les dossiers de code qu'il remplace, puis met à jour `client/`, `server/app/`, `VERSION`, `README.md` et `docs/`. Il ne touche pas à la base, au fichier `.env` ni aux environnements virtuels.
6. Redémarrer l'API. Au démarrage, SQLAlchemy crée les nouvelles tables manquantes sans supprimer les tables ni les enregistrements existants.
7. Relancer le client graphique.

Pour une installation locale utilisant SQLite, la base se trouve normalement dans `server/scolarite_uma.db`. Ne pas la supprimer. Pour une installation PostgreSQL, conserver le volume de données Docker.

Aucune dépendance graphique nouvelle n'a été ajoutée : le client utilise toujours `PySide6-Essentials` et `requests`. Il n'est donc pas nécessaire de réinstaller le client pour cette évolution, à condition que son environnement virtuel actuel fonctionne.

## Limites de vérification

Vérifications réalisées dans l'environnement de construction : compilation syntaxique Python, création des nouvelles tables sur SQLite temporaire et tests d'intégration API sur SQLite temporaire couvrant la création et la lecture des référentiels, leurs dépendances et une inscription. L'interface graphique n'a pas pu être lancée ici, car PySide6 n'est pas installé dans l'environnement de construction. Aucun test sur votre ordinateur ni sur votre base réelle n'a été exécuté.

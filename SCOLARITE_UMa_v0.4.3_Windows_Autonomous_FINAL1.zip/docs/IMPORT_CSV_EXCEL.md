# Importation CSV et Excel — SCOLARITÉ UMa 0.3.0

## Rubriques prises en charge

| Rubrique | Clé d'unicité | Colonnes obligatoires |
|---|---|---|
| Étudiants | matricule | matricule, last_name, first_name |
| Facultés | code | code, name |
| Départements | code | code, name, faculty_code |
| Filières | code | code, name, department_code |
| Niveaux | code | code, name, rank |
| Années académiques | year_label | year_label |
| Enseignants | employee_number | employee_number, last_name |
| UE | code | code, title, program_code, level_code |
| Cours | code | code, title, ue_code |
| Inscriptions | matricule + filière + année | student_matricule, program_code, level_code, academic_year |

## Règles appliquées

- Formats : `.csv` ou `.xlsx`. Les fichiers `.xls` historiques ne sont pas pris en charge.
- Taille maximale : 10 Mo. Maximum : 5 000 lignes de données par fichier.
- Les colonnes doivent correspondre au modèle fourni ou aux libellés français reconnus.
- Les dates d'étudiant acceptent `AAAA-MM-JJ` ou `JJ/MM/AAAA`.
- Les crédits et rangs doivent être des nombres entiers ; les coefficients acceptent le point ou la virgule décimale.
- Les relations doivent déjà exister dans la base : une faculté avant son département, un département avant sa filière, etc. Importer les différentes rubriques dans l'ordre indiqué dans le README.
- Les enregistrements déjà présents (ou répétés dans le même fichier) sont signalés comme doublons et ignorés.
- Si au moins une ligne contient une erreur, la validation du fichier échoue et aucune ligne de ce fichier n'est insérée. Corrigez les erreurs puis recommencez.
- L'analyse préalable ne modifie pas la base. Le serveur réanalyse aussi le fichier lors de l'import final.
- Les opérations réussies génèrent une entrée d'audit.

## Séquence d'utilisation

1. Ouvrir la rubrique dans le logiciel.
2. Télécharger **Modèle Excel**.
3. Renseigner les colonnes de la première feuille sans renommer les en-têtes.
4. Choisir **Importer CSV / Excel** et sélectionner le fichier.
5. Cliquer sur **Analyser le fichier**.
6. Corriger toutes les erreurs indiquées.
7. Refaire l'analyse puis confirmer avec **Importer les données**.
8. Actualiser la page et vérifier les enregistrements créés.

Les comptes utilisateurs et mots de passe ne sont pas importés depuis un tableur. La création des comptes doit être réalisée par une procédure administrateur dédiée.

# Paramètres académiques — démonstration LMD

La base est livrée sans étudiants, enseignants, facultés ou filières préchargés. Les données sont à saisir ou importer par l'utilisateur.

Paramètres de démonstration proposés :
- Système : LMD.
- Note maximale : 20.
- Seuil de validation : 10/20.
- Crédits minimaux par semestre : 30.
- Moyenne de cours : notes publiées normalisées sur 20 et pondérées par le poids de l'évaluation et le coefficient du cours.
- Moyenne d'UE : moyenne pondérée des cours par leur coefficient.
- Moyenne de semestre : moyenne des UE pondérée par leurs crédits.
- Semestre validé si la moyenne atteint le seuil et si le minimum de crédits validés est atteint.

Ces règles sont des hypothèses de démonstration modifiables depuis Paramètres. Elles ne remplacent pas le règlement pédagogique officiel de l'Université de Maroua. Les règles de compensation, de rattrapage, de jury et de progression doivent être confirmées avant toute utilisation institutionnelle.

## Ordre recommandé de saisie/import
1. Facultés
2. Départements
3. Filières
4. Niveaux et années académiques
5. Enseignants
6. UE
7. Cours
8. Étudiants
9. Inscriptions
10. Comptes utilisateurs (création sécurisée depuis l'application)
11. Sessions et évaluations
12. Notes

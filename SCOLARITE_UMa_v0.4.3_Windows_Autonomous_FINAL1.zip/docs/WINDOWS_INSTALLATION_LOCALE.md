# Installation Windows autonome — SCOLARITÉ UMa 0.4.3

## Objectif

Fournir un seul installateur `SCOLARITE_UMa_Setup.exe` pour Windows 10/11 64 bits. Il installe le client PySide6, l'API FastAPI et le mécanisme de base SQLite locale. Aucun Python, PostgreSQL, Docker ou terminal n'est requis sur le poste cible.

## Architecture retenue

- `SCOLARITE-UMa.exe` : interface graphique.
- `SCOLARITE-UMa-Serveur.exe` : API FastAPI/Uvicorn, lancée automatiquement par le client au premier démarrage.
- SQLite : fichier `C:\ProgramData\SCOLARITE UMa\data\scolarite_uma.db`.
- Journaux : `C:\ProgramData\SCOLARITE UMa\logs\server.log`.
- Les données sont séparées du dossier Program Files pour survivre aux mises à jour et à la désinstallation.
- Le serveur écoute uniquement sur `127.0.0.1:8000` : l'instance est destinée à un seul ordinateur. Aucun accès réseau distant n'est ouvert.

## Installation côté utilisateur

1. Double-cliquer `SCOLARITE_UMa_Setup.exe`.
2. Accepter la demande de contrôle de compte Windows si elle apparaît.
3. Suivre l'assistant d'installation.
4. À la fin, l'assistant lance `SCOLARITE-UMa-Admin.exe` pour créer le premier compte administrateur. Choisir un identifiant et un mot de passe d'au moins 12 caractères.
5. Lancer SCOLARITÉ UMa depuis le raccourci du Bureau.

## Compilation automatisée

Le workflow `.github/workflows/build-windows.yml` s'exécute sur un runner Windows 2022 via GitHub Actions. Il construit trois exécutables PyInstaller puis les assemble dans un installateur Inno Setup. L'artefact `SCOLARITE_UMa_Setup.exe` est disponible dans les artefacts du workflow. Lorsqu'un tag `v*` est poussé, le fichier est aussi attaché à la GitHub Release.

## Sauvegarde et mises à jour

Avant toute mise à jour ou désinstallation, sauvegarder le dossier :

`C:\ProgramData\SCOLARITE UMa\data`

La désinstallation ne supprime volontairement pas ce dossier. Une mise à jour doit remplacer les exécutables sans effacer `data` ni `logs`.

## Limites et vérifications obligatoires

- Cette édition Windows autonome utilise SQLite et est prévue pour une installation monoposte. Elle n'est pas le mode multi-postes partagé.
- La base SQLite est créée automatiquement par SQLAlchemy au démarrage de l'API. Le premier compte administrateur est créé par l'assistant post-installation.
- La compilation GitHub Actions doit être exécutée et le programme doit être testé sur de vrais Windows 10 et 11 avant diffusion.
- Tester notamment : premier démarrage, création du compte administrateur, connexion, import XLSX, génération PDF, redémarrage Windows, sauvegarde/restauration et mise à jour sans perte de données.
- Les règles de calcul LMD restent configurables et doivent être validées par l'établissement avant usage officiel.

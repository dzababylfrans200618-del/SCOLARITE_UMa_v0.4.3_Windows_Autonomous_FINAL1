#define AppName "SCOLARITÉ UMa"
#define AppVersion "0.4.3"
#define AppPublisher "SCOLARITÉ UMa"
[Setup]
AppId={{6F6C1D7A-BC2E-4A7D-9E33-6F1C3C7A0430}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\SCOLARITE UMa
DefaultGroupName={#AppName}
OutputDir=..\..\dist-installer
OutputBaseFilename=SCOLARITE_UMa_Setup
ArchitecturesInstallIn64BitMode=x64
ArchitecturesAllowed=x64
PrivilegesRequired=admin
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\SCOLARITE-UMa.exe
[Dirs]
Name: "{commonappdata}\SCOLARITE UMa\data"; Permissions: users-modify
Name: "{commonappdata}\SCOLARITE UMa\logs"; Permissions: users-modify
[Files]
Source: "..\..\dist\client\SCOLARITE-UMa.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\dist\server\SCOLARITE-UMa-Serveur.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\dist\admin\SCOLARITE-UMa-Admin.exe"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{group}\SCOLARITÉ UMa"; Filename: "{app}\SCOLARITE-UMa.exe"
Name: "{commondesktop}\SCOLARITÉ UMa"; Filename: "{app}\SCOLARITE-UMa.exe"; Tasks: desktopicon
Name: "{group}\Créer le compte administrateur"; Filename: "{app}\SCOLARITE-UMa-Admin.exe"
[Tasks]
Name: "desktopicon"; Description: "Créer un raccourci sur le Bureau"; GroupDescription: "Raccourcis :"
[Run]
Filename: "{app}\SCOLARITE-UMa-Admin.exe"; Description: "Créer le premier compte administrateur"; Flags: postinstall skipifsilent
[UninstallDelete]
; Les données utilisateur dans ProgramData sont volontairement conservées.

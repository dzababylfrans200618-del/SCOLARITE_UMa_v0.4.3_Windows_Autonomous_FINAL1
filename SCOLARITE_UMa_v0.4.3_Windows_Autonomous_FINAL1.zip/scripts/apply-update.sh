#!/usr/bin/env bash
set -Eeuo pipefail

ARCHIVE="${1:-}"
TARGET_ROOT="${2:-}"
if [[ -z "$ARCHIVE" || -z "$TARGET_ROOT" ]]; then
  echo "Usage : $0 /chemin/SCOLARITE_UMa_v0.2.0.zip /chemin/du/projet-existant" >&2
  exit 2
fi
command -v unzip >/dev/null 2>&1 || { echo "La commande unzip est requise." >&2; exit 1; }
[[ -f "$ARCHIVE" ]] || { echo "Archive introuvable : $ARCHIVE" >&2; exit 1; }
[[ -d "$TARGET_ROOT/client" && -d "$TARGET_ROOT/server/app" ]] || {
  echo "Le dossier cible ne ressemble pas à un projet SCOLARITÉ UMa : $TARGET_ROOT" >&2
  exit 1
}

TARGET_ROOT="$(cd "$TARGET_ROOT" && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
unzip -q "$ARCHIVE" -d "$TMP_DIR"
# Les archives distribuées peuvent avoir les fichiers directement à la racine
# ou être contenues dans un dossier SCOLARITE_UMa/.
if [[ -d "$TMP_DIR/SCOLARITE_UMa/client" && -d "$TMP_DIR/SCOLARITE_UMa/server/app" ]]; then
  SOURCE_ROOT="$TMP_DIR/SCOLARITE_UMa"
elif [[ -d "$TMP_DIR/client" && -d "$TMP_DIR/server/app" ]]; then
  SOURCE_ROOT="$TMP_DIR"
else
  echo "Structure de l'archive invalide : dossiers client/ et server/app/ introuvables." >&2
  echo "Contenu détecté :" >&2
  find "$TMP_DIR" -maxdepth 3 -type d | head -40 >&2
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$TARGET_ROOT/backups/code-update-$STAMP"
mkdir -p "$BACKUP"
cp -a "$TARGET_ROOT/client" "$BACKUP/"
cp -a "$TARGET_ROOT/server/app" "$BACKUP/server-app"
cp -f "$TARGET_ROOT/server/requirements.txt" "$BACKUP/server-requirements.txt"

cp -a "$SOURCE_ROOT/client/." "$TARGET_ROOT/client/"
cp -a "$SOURCE_ROOT/server/app/." "$TARGET_ROOT/server/app/"
cp -f "$SOURCE_ROOT/server/requirements.txt" "$TARGET_ROOT/server/requirements.txt"
cp -f "$SOURCE_ROOT/VERSION" "$TARGET_ROOT/VERSION"
cp -f "$SOURCE_ROOT/README.md" "$TARGET_ROOT/README.md"
mkdir -p "$TARGET_ROOT/docs"
cp -a "$SOURCE_ROOT/docs/." "$TARGET_ROOT/docs/"

printf '\nMise à jour du code terminée.\n'
printf 'Sauvegarde du code précédent : %s\n' "$BACKUP"
printf 'La base de données, le fichier .env et les environnements virtuels n’ont pas été modifiés.\n'
printf 'Mettez à jour les dépendances serveur : server/.venv/bin/pip install -r server/requirements.txt\n'
printf 'Redémarrez maintenant l’API puis relancez le client.\n'

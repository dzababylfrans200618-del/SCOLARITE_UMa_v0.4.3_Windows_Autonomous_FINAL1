#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON="${PYTHON:-python3}"
command -v "$PYTHON" >/dev/null 2>&1 || { echo "Python 3 est requis." >&2; exit 1; }

VENV="$ROOT/.venv-client"
"$PYTHON" -m venv "$VENV"
"$VENV/bin/python" -m pip install --disable-pip-version-check --retries 12 --timeout 90 \
  -r "$ROOT/client/requirements.txt"

mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
cat > "$HOME/.local/bin/scolarite-uma" <<LAUNCH
#!/usr/bin/env bash
ROOT="$ROOT"
export SCOLARITE_API_URL="\${SCOLARITE_API_URL:-http://127.0.0.1:8000}"
exec "$VENV/bin/python" "$ROOT/client/main.py" "\$@"
LAUNCH
chmod +x "$HOME/.local/bin/scolarite-uma"
cat > "$HOME/.local/share/applications/scolarite-uma.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=SCOLARITÉ UMa
Comment=Gestion académique de l'Université de Maroua
Exec=$HOME/.local/bin/scolarite-uma
Terminal=false
Categories=Office;Education;
DESKTOP

echo "Installation du client terminée. Lancez : scolarite-uma"
echo "Si la commande est introuvable : export PATH=\"\$HOME/.local/bin:\$PATH\""

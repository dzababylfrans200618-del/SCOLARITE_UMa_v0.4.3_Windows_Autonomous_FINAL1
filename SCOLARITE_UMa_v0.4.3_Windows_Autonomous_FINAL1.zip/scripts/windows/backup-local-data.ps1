param([string]$Destination = "$env:USERPROFILE\Documents\SCOLARITE_UMa_Backups")
$ErrorActionPreference = 'Stop'
$Source = Join-Path $env:ProgramData 'SCOLARITE UMa\data'
if (-not (Test-Path $Source)) { throw "Dossier de données introuvable : $Source" }
New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$Target = Join-Path $Destination "SCOLARITE_UMa-data-$Stamp.zip"
Compress-Archive -Path (Join-Path $Source '*') -DestinationPath $Target -CompressionLevel Optimal
Write-Host "Sauvegarde créée : $Target"

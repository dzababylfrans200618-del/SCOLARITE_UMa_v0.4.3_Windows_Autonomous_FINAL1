param([Parameter(Mandatory=$true)][string]$Archive)
$ErrorActionPreference = 'Stop'
$Target = Join-Path $env:ProgramData 'SCOLARITE UMa\data'
if (-not (Test-Path $Archive)) { throw "Archive introuvable : $Archive" }
if (Test-Path $Target) {
  $Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  Rename-Item -Path $Target -NewName "data-before-restore-$Stamp"
}
New-Item -ItemType Directory -Force -Path $Target | Out-Null
Expand-Archive -Path $Archive -DestinationPath $Target -Force
Write-Host 'Restauration terminée. Relancez SCOLARITÉ UMa.'

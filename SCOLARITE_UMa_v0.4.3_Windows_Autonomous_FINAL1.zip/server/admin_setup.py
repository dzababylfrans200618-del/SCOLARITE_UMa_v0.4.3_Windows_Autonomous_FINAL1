"""Création interactive du premier compte administrateur local."""
import getpass
import os
from pathlib import Path
_data_dir = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "SCOLARITE UMa" / "data"
_data_dir.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("SCOLARITE_DATA_DIR", str(_data_dir))
from sqlalchemy import select
from app.database import Base, engine, SessionLocal
from app.models import User
from app.security import hash_password


def main():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.scalar(select(User.id).limit(1)):
            print("Un compte existe déjà. Aucun compte supplémentaire créé.")
            return
        username = input("Identifiant administrateur [admin] : ").strip() or "admin"
        full_name = input("Nom complet : ").strip() or "Administrateur SCOLARITÉ UMa"
        while True:
            password = getpass.getpass("Mot de passe (12 caractères minimum) : ")
            confirm = getpass.getpass("Confirmer le mot de passe : ")
            if len(password) < 12:
                print("Le mot de passe doit contenir au moins 12 caractères.")
            elif password != confirm:
                print("Les mots de passe ne correspondent pas.")
            else:
                break
        db.add(User(username=username, full_name=full_name, password_hash=hash_password(password), role="admin"))
        db.commit()
        print("Compte administrateur créé. Vous pouvez lancer SCOLARITÉ UMa.")
    finally:
        db.close()
    input("Appuyez sur Entrée pour fermer...")


if __name__ == "__main__":
    main()

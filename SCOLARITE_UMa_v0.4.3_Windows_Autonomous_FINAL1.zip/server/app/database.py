import os
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

# En mode Windows autonome, les données résident hors de Program Files afin
# de survivre aux mises à jour et de respecter les droits Windows.
_data_dir = os.getenv("SCOLARITE_DATA_DIR")
if _data_dir and not os.getenv("DATABASE_URL"):
    _db_dir = Path(_data_dir)
    _db_dir.mkdir(parents=True, exist_ok=True)
    DATABASE_URL = f"sqlite:///{(_db_dir / 'scolarite_uma.db').as_posix()}"
else:
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./scolarite_uma.db")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, pool_pre_ping=True, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

"""CSV/XLSX import helpers for SCOLARITE UMa.

The parser is intentionally strict about required columns and row types. It does
not perform database writes; validation and commit are handled by the API layer.
"""
from __future__ import annotations

import csv
import io
import unicodedata
from datetime import date, datetime
from typing import Any

MAX_IMPORT_BYTES = 10 * 1024 * 1024
MAX_IMPORT_ROWS = 5000

ALIASES = {
    "matricule": "matricule", "matricule etudiant": "matricule",
    "nom": "last_name", "nom de famille": "last_name", "last name": "last_name",
    "prenom": "first_name", "prenoms": "first_name", "prenom(s)": "first_name", "first name": "first_name",
    "sexe": "sex", "genre": "sex", "date de naissance": "birth_date", "naissance": "birth_date",
    "telephone": "phone", "tel": "phone", "numero de telephone": "phone",
    "courriel": "email", "adresse email": "email", "email": "email",
    "filiere": "program", "code filiere": "program_code", "niveau": "level", "code niveau": "level_code",
    "code": "code", "nom de la faculte": "name", "faculte": "faculty_code",
    "nom du departement": "name", "departement": "department_code", "nom de la filiere": "name",
    "intitule": "title", "intitule ue": "title", "intitule du cours": "title",
    "credits": "credits", "credit": "credits", "coefficient": "coefficient", "semestre": "semester",
    "annee academique": "academic_year", "annee": "year_label", "libelle annee": "year_label",
    "date debut": "start_date", "date de debut": "start_date", "date fin": "end_date", "date de fin": "end_date",
    "specialite": "specialty", "matricule enseignant": "employee_number", "numero personnel": "employee_number",
    "type inscription": "registration_type", "type d inscription": "registration_type",
    "statut": "status", "description": "description", "ordre": "rank", "rang": "rank",
    "code faculte": "faculty_code", "code departement": "department_code", "code ue": "ue_code",
    "enseignant": "teacher_number", "matricule enseignant responsable": "teacher_number",
}


def _norm(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return " ".join(text.casefold().replace("_", " ").replace("-", " ").split())


def _canonical_header(value: Any, allowed_fields: list[str]) -> str | None:
    raw = str(value or "").strip()
    if raw in allowed_fields:
        return raw
    normalized = _norm(raw)
    if normalized in ALIASES:
        candidate = ALIASES[normalized]
        if candidate in allowed_fields:
            return candidate
    # Support French labels whose exact canonical field already appears as a token.
    canonical_by_norm = {_norm(field): field for field in allowed_fields}
    return canonical_by_norm.get(normalized)


def _read_csv(content: bytes) -> list[list[Any]]:
    decoded = None
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            decoded = content.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    if decoded is None:
        raise ValueError("Encodage CSV non reconnu. Enregistrez le fichier en UTF-8.")
    sample = decoded[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=";,\t|")
    except csv.Error:
        first_line = sample.splitlines()[0] if sample.splitlines() else ""
        delimiter = ";" if first_line.count(";") >= first_line.count(",") else ","
        dialect = csv.excel
        dialect.delimiter = delimiter
    return list(csv.reader(io.StringIO(decoded), dialect))


def read_tabular_file(content: bytes, filename: str, allowed_fields: list[str], required_fields: list[str]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    if not content:
        raise ValueError("Le fichier est vide.")
    if len(content) > MAX_IMPORT_BYTES:
        raise ValueError(f"Fichier trop volumineux : maximum {MAX_IMPORT_BYTES // (1024 * 1024)} Mo.")
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if ext == "csv":
        raw_rows = _read_csv(content)
    elif ext == "xlsx":
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise ValueError("La lecture Excel nécessite openpyxl. Installez les dépendances du serveur.") from exc
        try:
            workbook = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
            sheet = workbook.active
            raw_rows = [list(row) for row in sheet.iter_rows(values_only=True)]
            workbook.close()
        except Exception as exc:
            raise ValueError(f"Fichier Excel illisible : {exc}") from exc
    else:
        raise ValueError("Format non pris en charge. Utilisez un fichier .csv ou .xlsx (Excel).")

    while raw_rows and not any(str(v or "").strip() for v in raw_rows[0]):
        raw_rows.pop(0)
    if not raw_rows:
        raise ValueError("Aucune ligne d'en-tête n'a été trouvée.")

    header_row = raw_rows[0]
    mapping: dict[int, str] = {}
    seen: set[str] = set()
    for idx, header in enumerate(header_row):
        field = _canonical_header(header, allowed_fields)
        if field:
            if field in seen:
                raise ValueError(f"La colonne '{field}' apparaît plusieurs fois.")
            mapping[idx] = field
            seen.add(field)
    missing = [field for field in required_fields if field not in seen]
    if missing:
        raise ValueError("Colonnes obligatoires absentes : " + ", ".join(missing) + ". Utilisez le modèle fourni.")

    parsed: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    data_rows = raw_rows[1:]
    if len(data_rows) > MAX_IMPORT_ROWS:
        raise ValueError(f"Le fichier contient {len(data_rows)} lignes. Maximum autorisé : {MAX_IMPORT_ROWS}.")
    for line_number, raw in enumerate(data_rows, start=2):
        if not any(str(v or "").strip() for v in raw):
            continue
        item: dict[str, Any] = {}
        for col_index, field in mapping.items():
            value = raw[col_index] if col_index < len(raw) else None
            if isinstance(value, (datetime, date)):
                value = value.isoformat()
            elif value is None:
                value = ""
            item[field] = value.strip() if isinstance(value, str) else value
        item["_line"] = line_number
        parsed.append(item)
    return parsed, errors


def normalize_import_value(field: str, value: Any) -> Any:
    if value is None:
        value = ""
    if field == "birth_date":
        if value == "":
            return None
        if isinstance(value, (datetime, date)):
            return value.date() if isinstance(value, datetime) else value
        text = str(value).strip()
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"):
            try:
                return datetime.strptime(text, fmt).date()
            except ValueError:
                pass
        raise ValueError("date de naissance invalide (formats acceptés : AAAA-MM-JJ ou JJ/MM/AAAA)")
    if field in {"rank", "credits"}:
        return int(str(value).strip() if str(value).strip() else 0)
    if field in {"coefficient"}:
        numeric = str(value).strip().replace(" ", "").replace(",", ".") if str(value).strip() else "1"
        return float(numeric)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return str(value).strip()

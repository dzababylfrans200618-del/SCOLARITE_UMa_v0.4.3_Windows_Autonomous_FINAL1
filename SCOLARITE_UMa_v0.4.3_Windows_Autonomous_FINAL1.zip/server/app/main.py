from datetime import date
import csv
import io
from fastapi import FastAPI, Depends, HTTPException, Body, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError
from fastapi.responses import StreamingResponse
from .database import Base, engine, get_db
from .models import (User, Student, AuditLog, Faculty, Department, Program, AcademicLevel, AcademicYear, Teacher, TeachingUnit, Course, Enrollment, ExamSession, Assessment, Grade, TimetableEntry, AppSetting)
from .security import verify_password, create_token, current_user, require_roles
from .imports import read_tabular_file, normalize_import_value

Base.metadata.create_all(bind=engine)
app = FastAPI(title="SCOLARITE UMa API", version="0.4.0", docs_url="/api/docs")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost"], allow_credentials=True, allow_methods=["GET","POST","PUT","DELETE"], allow_headers=["Authorization","Content-Type"])

class StudentIn(BaseModel):
    matricule: str = Field(min_length=2, max_length=40)
    last_name: str = Field(min_length=1, max_length=100)
    first_name: str = Field(min_length=1, max_length=120)
    sex: str = Field(default="", max_length=1)
    birth_date: date | None = None
    phone: str = ""
    email: str = ""
    program: str = ""
    level: str = ""
    status: str = "actif"

class StudentOut(StudentIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    status: str

@app.get("/health")
def health():
    return {"status": "ok", "service": "SCOLARITE UMa API", "version": app.version}

@app.post("/auth/login")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == form.username))
    if not user or not user.active or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Identifiants incorrects")
    return {"access_token": create_token(user), "token_type": "bearer", "full_name": user.full_name, "role": user.role}

@app.get("/auth/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "username": user.username, "full_name": user.full_name, "role": user.role}

@app.get("/dashboard")
def dashboard(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return {"students": db.scalar(select(func.count()).select_from(Student)) or 0,
            "active_students": db.scalar(select(func.count()).select_from(Student).where(Student.status == "actif")) or 0,
            "users": db.scalar(select(func.count()).select_from(User)) or 0,
            "enrollments": db.scalar(select(func.count()).select_from(Enrollment)) or 0,
            "faculties": db.scalar(select(func.count()).select_from(Faculty)) or 0,
            "departments": db.scalar(select(func.count()).select_from(Department)) or 0,
            "programs": db.scalar(select(func.count()).select_from(Program)) or 0,
            "teachers": db.scalar(select(func.count()).select_from(Teacher)) or 0,
            "connected_as": user.full_name}

@app.get("/students", response_model=list[StudentOut])
def list_students(q: str = "", db: Session = Depends(get_db), user: User = Depends(current_user)):
    stmt = select(Student).order_by(Student.last_name, Student.first_name)
    if q.strip():
        term = f"%{q.strip()}%"
        stmt = stmt.where((Student.matricule.ilike(term)) | (Student.last_name.ilike(term)) | (Student.first_name.ilike(term)))
    return db.scalars(stmt.limit(500)).all()

@app.post("/students", response_model=StudentOut, status_code=201)
def create_student(data: StudentIn, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "scolarite"))):
    if db.scalar(select(Student).where(Student.matricule == data.matricule)):
        raise HTTPException(status_code=409, detail="Ce matricule existe déjà")
    student = Student(**data.model_dump())
    db.add(student); db.flush()
    db.add(AuditLog(user_id=user.id, action="CREATION", entity="Student", entity_id=str(student.id), details=f"Création du dossier {student.matricule}"))
    db.commit(); db.refresh(student)
    return student

@app.put("/students/{student_id}", response_model=StudentOut)
def update_student(student_id: int, data: StudentIn, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "scolarite"))):
    student = db.get(Student, student_id)
    if not student: raise HTTPException(status_code=404, detail="Étudiant introuvable")
    duplicate = db.scalar(select(Student).where(Student.matricule == data.matricule, Student.id != student_id))
    if duplicate: raise HTTPException(status_code=409, detail="Ce matricule est déjà attribué")
    for key, value in data.model_dump().items(): setattr(student, key, value)
    db.add(AuditLog(user_id=user.id, action="MODIFICATION", entity="Student", entity_id=str(student.id), details=f"Modification du dossier {student.matricule}"))
    db.commit(); db.refresh(student)
    return student

@app.post("/students/{student_id}/archive")
def archive_student(student_id: int, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "scolarite"))):
    student = db.get(Student, student_id)
    if not student: raise HTTPException(status_code=404, detail="Étudiant introuvable")
    student.status = "archive"
    db.add(AuditLog(user_id=user.id, action="ARCHIVAGE", entity="Student", entity_id=str(student.id), details=f"Archivage du dossier {student.matricule}"))
    db.commit()
    return {"message": "Dossier archivé"}


# ---------------------------------------------------------------------------
# Import de masse CSV / Excel (.xlsx), avec prévalidation et rapport détaillé.
# ---------------------------------------------------------------------------
STUDENT_IMPORT_FIELDS = ["matricule", "last_name", "first_name", "sex", "birth_date", "phone", "email", "program", "level", "status"]
STUDENT_IMPORT_REQUIRED = ["matricule", "last_name", "first_name"]


def import_config(entity: str):
    if entity == "etudiants":
        return {"model": Student, "fields": STUDENT_IMPORT_FIELDS, "required": STUDENT_IMPORT_REQUIRED,
                "writers": ["admin", "scolarite"], "kind": "student"}
    config = CATALOGS.get(entity)
    if not config:
        raise HTTPException(status_code=404, detail="Type de données non pris en charge pour l'import")
    return {**config, "kind": "catalog"}


def _import_unique_key(entity: str, values: dict):
    keys = {
        "etudiants": ("matricule",),
        "facultes": ("code",), "departements": ("code",), "filieres": ("code",),
        "niveaux": ("code",), "annees-academiques": ("year_label",), "enseignants": ("employee_number",),
        "ue": ("code",), "cours": ("code",),
        "inscriptions": ("student_matricule", "program_code", "academic_year"),
    }
    return tuple(values.get(k, "") for k in keys[entity])


def _validate_import_row(entity: str, raw: dict, config: dict, db: Session):
    values = {}
    for field in config["fields"]:
        if field in raw:
            values[field] = normalize_import_value(field, raw[field])
    for field in config["required"]:
        if field not in values or values[field] in (None, ""):
            raise ValueError(f"Champ obligatoire manquant : {field}")
    if config["kind"] == "student":
        if values.get("sex") and str(values["sex"]).upper() not in ("M", "F"):
            raise ValueError("Le sexe doit être M ou F")
        values["sex"] = str(values.get("sex", "")).upper()
        values.setdefault("status", "actif")
        return values
    values = normalize_catalog_payload(values, config)
    validate_catalog_dependencies(entity, values, db)
    return values


def _existing_import_duplicate(entity: str, values: dict, db: Session):
    config = import_config(entity)
    model = config["model"]
    keys = {
        "etudiants": ("matricule",),
        "facultes": ("code",), "departements": ("code",), "filieres": ("code",),
        "niveaux": ("code",), "annees-academiques": ("year_label",), "enseignants": ("employee_number",),
        "ue": ("code",), "cours": ("code",),
        "inscriptions": ("student_matricule", "program_code", "academic_year"),
    }[entity]
    filters = [getattr(model, key) == values[key] for key in keys]
    from sqlalchemy import and_
    return db.scalar(select(model).where(and_(*filters))) is not None


def _parse_import_upload(entity: str, filename: str, content: bytes, db: Session):
    config = import_config(entity)
    raw_rows, _ = read_tabular_file(content, filename, config["fields"], config["required"])
    valid_rows = []
    issues = []
    duplicates = 0
    seen = set()
    for raw in raw_rows:
        line = raw.pop("_line", 0)
        try:
            values = _validate_import_row(entity, raw, config, db)
            key = _import_unique_key(entity, values)
            if key in seen or _existing_import_duplicate(entity, values, db):
                duplicates += 1
                continue
            seen.add(key)
            valid_rows.append((line, values))
        except HTTPException as exc:
            issues.append({"ligne": line, "erreur": str(exc.detail)})
        except (ValueError, TypeError) as exc:
            issues.append({"ligne": line, "erreur": str(exc)})
    return config, valid_rows, duplicates, issues, len(raw_rows)


@app.get("/imports/{entity}/template")
def import_template(entity: str, format: str = Query("csv", pattern="^(csv|xlsx)$"),
                    user: User = Depends(current_user)):
    config = import_config(entity)
    headers = config["fields"]
    if format == "csv":
        stream = io.StringIO(newline="")
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(headers)
        body = stream.getvalue().encode("utf-8-sig")
        media_type = "text/csv; charset=utf-8"
        filename = f"modele_import_{entity}.csv"
    else:
        try:
            from openpyxl import Workbook
        except ImportError:
            raise HTTPException(status_code=503, detail="Le module openpyxl n'est pas installé sur le serveur")
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Import"
        sheet.append(headers)
        sheet.freeze_panes = "A2"
        from openpyxl.styles import Font
        from openpyxl.utils import get_column_letter
        for cell in sheet[1]:
            cell.font = Font(bold=True)
        for idx, header in enumerate(headers, start=1):
            sheet.column_dimensions[get_column_letter(idx)].width = max(16, len(header) + 4)
        buffer = io.BytesIO()
        workbook.save(buffer)
        body = buffer.getvalue()
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        filename = f"modele_import_{entity}.xlsx"
    return StreamingResponse(io.BytesIO(body), media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/imports/{entity}")
async def import_data(entity: str, file: UploadFile = File(...), dry_run: bool = Query(True),
                      db: Session = Depends(get_db), user: User = Depends(current_user)):
    config = import_config(entity)
    if user.role not in config["writers"]:
        raise HTTPException(status_code=403, detail="Droits insuffisants pour importer dans cette rubrique")
    content = await file.read(10 * 1024 * 1024 + 1)
    try:
        _cfg, valid_rows, duplicate_count, issues, total_rows = _parse_import_upload(entity, file.filename or "import", content, db)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    summary = {
        "entity": entity, "file": file.filename, "total_lignes": total_rows,
        "lignes_valides": len(valid_rows), "doublons_ignores": duplicate_count,
        "erreurs": len(issues), "details_erreurs": issues[:200], "simulation": bool(dry_run),
    }
    if dry_run:
        return summary
    if issues:
        summary["import_effectue"] = False
        summary["message"] = "Import annulé : corrigez les lignes en erreur puis relancez l'import. Aucun enregistrement n'a été ajouté."
        return summary
    inserted = 0
    try:
        for line, values in valid_rows:
            item = config["model"](**values)
            db.add(item)
            db.flush()
            db.add(AuditLog(user_id=user.id, action="IMPORT", entity=entity,
                            entity_id=str(item.id), details=f"Import depuis {file.filename}, ligne {line}"))
            inserted += 1
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Conflit d'intégrité pendant l'import. Aucun enregistrement n'a été conservé.")
    except Exception:
        db.rollback()
        raise
    summary.update({"simulation": False, "import_effectue": True, "enregistrements_crees": inserted,
                    "message": f"Import terminé : {inserted} enregistrement(s) créé(s)."})
    return summary


# ---------------------------------------------------------------------------
# Référentiels académiques : API CRUD commune et contrôlée par rôle.
# ---------------------------------------------------------------------------
CATALOGS = {
    "facultes": {"model": Faculty, "fields": ["code", "name", "description", "status"], "required": ["code", "name"], "search": ["code", "name"], "writers": ["admin", "responsable_pedagogique"]},
    "departements": {"model": Department, "fields": ["code", "name", "faculty_code", "description", "status"], "required": ["code", "name", "faculty_code"], "search": ["code", "name", "faculty_code"], "writers": ["admin", "responsable_pedagogique"]},
    "filieres": {"model": Program, "fields": ["code", "name", "department_code", "description", "status"], "required": ["code", "name", "department_code"], "search": ["code", "name", "department_code"], "writers": ["admin", "responsable_pedagogique"]},
    "niveaux": {"model": AcademicLevel, "fields": ["code", "name", "rank", "description", "status"], "required": ["code", "name", "rank"], "search": ["code", "name"], "writers": ["admin", "responsable_pedagogique"]},
    "annees-academiques": {"model": AcademicYear, "fields": ["year_label", "start_date", "end_date", "status"], "required": ["year_label"], "search": ["year_label", "status"], "writers": ["admin", "scolarite"]},
    "enseignants": {"model": Teacher, "fields": ["employee_number", "last_name", "first_name", "specialty", "email", "phone", "status"], "required": ["employee_number", "last_name"], "search": ["employee_number", "last_name", "first_name", "specialty"], "writers": ["admin", "responsable_pedagogique"]},
    "ue": {"model": TeachingUnit, "fields": ["code", "title", "credits", "coefficient", "semester", "program_code", "level_code", "status"], "required": ["code", "title", "program_code", "level_code"], "search": ["code", "title", "program_code", "level_code"], "writers": ["admin", "responsable_pedagogique"]},
    "cours": {"model": Course, "fields": ["code", "title", "coefficient", "ue_code", "teacher_number", "status"], "required": ["code", "title", "ue_code"], "search": ["code", "title", "ue_code", "teacher_number"], "writers": ["admin", "responsable_pedagogique"]},
    "inscriptions": {"model": Enrollment, "fields": ["student_matricule", "program_code", "level_code", "academic_year", "registration_type", "status"], "required": ["student_matricule", "program_code", "level_code", "academic_year"], "search": ["student_matricule", "program_code", "level_code", "academic_year", "status"], "writers": ["admin", "scolarite"]},
}

NUMERIC_FIELDS = {"rank": int, "credits": int, "coefficient": float}

def catalog_config(entity: str):
    config = CATALOGS.get(entity)
    if not config:
        raise HTTPException(status_code=404, detail="Rubrique inconnue")
    return config

def serialize_catalog(item, fields):
    result = {"id": item.id}
    for field in fields:
        result[field] = getattr(item, field)
    return result

def normalize_catalog_payload(payload: dict, config: dict):
    if not isinstance(payload, dict):
        raise HTTPException(status_code=422, detail="Données invalides")
    unknown = set(payload) - set(config["fields"])
    if unknown:
        raise HTTPException(status_code=422, detail="Champs non autorisés : " + ", ".join(sorted(unknown)))
    values = {}
    for field in config["fields"]:
        if field not in payload:
            continue
        value = payload[field]
        if value is None:
            value = ""
        if field in NUMERIC_FIELDS:
            try:
                value = NUMERIC_FIELDS[field](value if str(value).strip() else 0)
            except (ValueError, TypeError):
                raise HTTPException(status_code=422, detail=f"Valeur numérique invalide : {field}")
        else:
            value = str(value).strip()
        values[field] = value
    for field in config["required"]:
        if field not in values or values[field] == "":
            raise HTTPException(status_code=422, detail=f"Le champ {field} est obligatoire")
    return values

def validate_catalog_dependencies(entity: str, values: dict, db: Session):
    checks = {
        "departements": ("faculty_code", Faculty, "code", "La faculté indiquée n'existe pas"),
        "filieres": ("department_code", Department, "code", "Le département indiqué n'existe pas"),
        "ue": ("program_code", Program, "code", "La filière indiquée n'existe pas"),
    }
    if entity in checks:
        field, model, attr, message = checks[entity]
        if not db.scalar(select(model).where(getattr(model, attr) == values[field], model.status == "actif")):
            raise HTTPException(status_code=422, detail=message)
    if entity == "ue":
        if not db.scalar(select(AcademicLevel).where(AcademicLevel.code == values["level_code"], AcademicLevel.status == "actif")):
            raise HTTPException(status_code=422, detail="Le niveau indiqué n'existe pas")
    elif entity == "cours":
        if not db.scalar(select(TeachingUnit).where(TeachingUnit.code == values["ue_code"], TeachingUnit.status == "actif")):
            raise HTTPException(status_code=422, detail="L'unité d'enseignement indiquée n'existe pas")
        teacher_number = values.get("teacher_number", "")
        if teacher_number and not db.scalar(select(Teacher).where(Teacher.employee_number == teacher_number, Teacher.status == "actif")):
            raise HTTPException(status_code=422, detail="L'enseignant indiqué n'existe pas")
    elif entity == "inscriptions":
        if not db.scalar(select(Student).where(Student.matricule == values["student_matricule"], Student.status == "actif")):
            raise HTTPException(status_code=422, detail="L'étudiant indiqué n'existe pas ou son dossier est archivé")
        if not db.scalar(select(Program).where(Program.code == values["program_code"], Program.status == "actif")):
            raise HTTPException(status_code=422, detail="La filière indiquée n'existe pas")
        if not db.scalar(select(AcademicLevel).where(AcademicLevel.code == values["level_code"], AcademicLevel.status == "actif")):
            raise HTTPException(status_code=422, detail="Le niveau indiqué n'existe pas")
        if not db.scalar(select(AcademicYear).where(AcademicYear.year_label == values["academic_year"])):
            raise HTTPException(status_code=422, detail="L'année académique indiquée n'existe pas")

@app.get("/catalog/{entity}")
def list_catalog(entity: str, q: str = "", db: Session = Depends(get_db), user: User = Depends(current_user)):
    config = catalog_config(entity)
    model = config["model"]
    stmt = select(model).order_by(model.id.desc())
    if q.strip():
        term = f"%{q.strip()}%"
        filters = [getattr(model, field).ilike(term) for field in config["search"]]
        from sqlalchemy import or_
        stmt = stmt.where(or_(*filters))
    rows = db.scalars(stmt.limit(1000)).all()
    return [serialize_catalog(row, config["fields"]) for row in rows]

@app.post("/catalog/{entity}", status_code=201)
def create_catalog(entity: str, payload: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(current_user)):
    config = catalog_config(entity)
    if user.role not in config["writers"]:
        raise HTTPException(status_code=403, detail="Droits insuffisants pour cette rubrique")
    values = normalize_catalog_payload(payload, config)
    validate_catalog_dependencies(entity, values, db)
    item = config["model"](**values)
    db.add(item)
    try:
        db.flush()
        db.add(AuditLog(user_id=user.id, action="CREATION", entity=entity, entity_id=str(item.id), details=f"Création dans {entity}"))
        db.commit(); db.refresh(item)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Un enregistrement avec ce code ou cette combinaison existe déjà")
    return serialize_catalog(item, config["fields"])

@app.put("/catalog/{entity}/{item_id}")
def update_catalog(entity: str, item_id: int, payload: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(current_user)):
    config = catalog_config(entity)
    if user.role not in config["writers"]:
        raise HTTPException(status_code=403, detail="Droits insuffisants pour cette rubrique")
    item = db.get(config["model"], item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Enregistrement introuvable")
    values = normalize_catalog_payload(payload, config)
    validate_catalog_dependencies(entity, values, db)
    for key, value in values.items():
        setattr(item, key, value)
    try:
        db.add(AuditLog(user_id=user.id, action="MODIFICATION", entity=entity, entity_id=str(item.id), details=f"Modification dans {entity}"))
        db.commit(); db.refresh(item)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Un enregistrement avec ce code ou cette combinaison existe déjà")
    return serialize_catalog(item, config["fields"])

@app.post("/catalog/{entity}/{item_id}/archive")
def archive_catalog(entity: str, item_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    config = catalog_config(entity)
    if user.role not in config["writers"]:
        raise HTTPException(status_code=403, detail="Droits insuffisants pour cette rubrique")
    item = db.get(config["model"], item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Enregistrement introuvable")
    if not hasattr(item, "status"):
        raise HTTPException(status_code=400, detail="Archivage indisponible pour cet enregistrement")
    item.status = "archive"
    db.add(AuditLog(user_id=user.id, action="ARCHIVAGE", entity=entity, entity_id=str(item.id), details=f"Archivage dans {entity}"))
    db.commit()
    return {"message": "Enregistrement archivé"}

# ---------------------------------------------------------------------------
# Modules académiques opérationnels : sessions, évaluations, notes, emplois du
# temps, comptes, paramètres, historique et exports de résultats.
# ---------------------------------------------------------------------------
from datetime import datetime
from sqlalchemy import and_, or_
from .security import hash_password

@app.get("/users")
def users_list(db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    return [{"id": u.id, "username": u.username, "full_name": u.full_name, "role": u.role, "active": u.active}
            for u in db.scalars(select(User).order_by(User.username)).all()]

@app.post("/users", status_code=201)
def users_create(payload: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))
    role = str(payload.get("role", "scolarite"))
    if not username or len(password) < 12 or role not in {"admin", "scolarite", "responsable_pedagogique", "enseignant", "etudiant", "direction"}:
        raise HTTPException(422, "Identifiant, mot de passe (12 caractères minimum) ou rôle invalide")
    if db.scalar(select(User).where(User.username == username)):
        raise HTTPException(409, "Cet identifiant existe déjà")
    item = User(username=username, full_name=str(payload.get("full_name", username)), password_hash=hash_password(password), role=role)
    db.add(item); db.flush(); db.add(AuditLog(user_id=user.id, action="CREATION", entity="User", entity_id=str(item.id), details=f"Création du compte {username}")); db.commit()
    return {"id": item.id, "username": item.username, "full_name": item.full_name, "role": item.role, "active": item.active}

@app.put("/users/{user_id}")
def users_update(user_id: int, payload: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    item = db.get(User, user_id)
    if not item: raise HTTPException(404, "Compte introuvable")
    if "full_name" in payload: item.full_name = str(payload["full_name"]).strip()
    if "role" in payload:
        if payload["role"] not in {"admin", "scolarite", "responsable_pedagogique", "enseignant", "etudiant", "direction"}: raise HTTPException(422, "Rôle invalide")
        item.role = payload["role"]
    if "active" in payload: item.active = bool(payload["active"])
    if payload.get("password"):
        if len(payload["password"]) < 12: raise HTTPException(422, "Mot de passe trop court")
        item.password_hash = hash_password(payload["password"])
    db.add(AuditLog(user_id=user.id, action="MODIFICATION", entity="User", entity_id=str(item.id), details=f"Modification du compte {item.username}")); db.commit()
    return {"id": item.id, "username": item.username, "full_name": item.full_name, "role": item.role, "active": item.active}

@app.get("/exam-sessions")
def exam_sessions_list(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [{k:getattr(x,k) for k in ("id","code","title","academic_year","semester","starts_on","ends_on","status")} for x in db.scalars(select(ExamSession).order_by(ExamSession.id.desc())).all()]

@app.post("/exam-sessions", status_code=201)
def exam_sessions_create(p: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin","scolarite","responsable_pedagogique"))):
    required = ["code","title","academic_year","semester"]
    if any(not str(p.get(k," ")).strip() for k in required): raise HTTPException(422,"Code, intitulé, année et semestre obligatoires")
    if not db.scalar(select(AcademicYear).where(AcademicYear.year_label==p["academic_year"])): raise HTTPException(422,"Année académique inconnue")
    item=ExamSession(**{k:p.get(k, "") for k in ("code","title","academic_year","semester","starts_on","ends_on","status")}); db.add(item)
    try: db.commit(); db.refresh(item)
    except IntegrityError: db.rollback(); raise HTTPException(409,"Code de session déjà utilisé")
    return {k:getattr(item,k) for k in ("id","code","title","academic_year","semester","starts_on","ends_on","status")}

@app.get("/assessments")
def assessments_list(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return [{k:getattr(x,k) for k in ("id","code","title","course_code","session_code","weight","max_score","status")} for x in db.scalars(select(Assessment).order_by(Assessment.id.desc())).all()]

@app.post("/assessments", status_code=201)
def assessments_create(p: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin","responsable_pedagogique","scolarite"))):
    for key, model, attr in (("course_code",Course,"code"),("session_code",ExamSession,"code")):
        if not db.scalar(select(model).where(getattr(model,attr)==p.get(key))): raise HTTPException(422,f"Référence {key} inconnue")
    try:
        item=Assessment(code=str(p["code"]).strip(), title=str(p["title"]).strip(), course_code=p["course_code"], session_code=p["session_code"], weight=float(p.get("weight",1)), max_score=float(p.get("max_score",20)), status="ouverte")
        if item.weight <= 0 or item.max_score <= 0: raise HTTPException(422,"Pondération et barème doivent être positifs")
        db.add(item); db.commit(); db.refresh(item)
    except IntegrityError: db.rollback(); raise HTTPException(409,"Code d'évaluation déjà utilisé")
    return {k:getattr(item,k) for k in ("id","code","title","course_code","session_code","weight","max_score","status")}

@app.get("/grades")
def grades_list(assessment_code: str = "", db: Session = Depends(get_db), user: User = Depends(current_user)):
    stmt=select(Grade).order_by(Grade.student_matricule)
    if assessment_code: stmt=stmt.where(Grade.assessment_code==assessment_code)
    if user.role=="etudiant":
        student=db.scalar(select(Student).where(Student.matricule==user.username))
        if not student: return []
        stmt=stmt.where(Grade.student_matricule==student.matricule, Grade.status=="publiee")
    return [{"id":g.id,"assessment_code":g.assessment_code,"student_matricule":g.student_matricule,"score":g.score,"status":g.status} for g in db.scalars(stmt.limit(5000)).all()]

@app.post("/grades", status_code=201)
def grade_upsert(p: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin","enseignant","scolarite"))):
    assessment=db.scalar(select(Assessment).where(Assessment.code==p.get("assessment_code")))
    student=db.scalar(select(Student).where(Student.matricule==p.get("student_matricule"), Student.status=="actif"))
    if not assessment or not student: raise HTTPException(422,"Évaluation ou étudiant introuvable")
    course=db.scalar(select(Course).where(Course.code==assessment.course_code))
    ue=db.scalar(select(TeachingUnit).where(TeachingUnit.code==course.ue_code)) if course else None
    if user.role=="enseignant" and (not course or course.teacher_number != user.username): raise HTTPException(403,"Vous ne pouvez saisir que les notes de vos cours affectés")
    if ue and not db.scalar(select(Enrollment).where(Enrollment.student_matricule==student.matricule,Enrollment.program_code==ue.program_code,Enrollment.level_code==ue.level_code,Enrollment.status.in_(["en attente","validée","actif"]))): raise HTTPException(422,"Cet étudiant n'est pas inscrit au niveau et à la filière de cette UE")
    if assessment.status != "ouverte": raise HTTPException(409,"Cette évaluation est verrouillée")
    try: score=float(p.get("score"))
    except (TypeError,ValueError): raise HTTPException(422,"Note invalide")
    if score < 0 or score > assessment.max_score: raise HTTPException(422,f"La note doit être comprise entre 0 et {assessment.max_score}")
    grade=db.scalar(select(Grade).where(Grade.assessment_code==assessment.code, Grade.student_matricule==student.matricule))
    if grade and grade.status in ("validee","publiee"): raise HTTPException(409,"Note validée : demander une correction au responsable pédagogique")
    if grade: grade.score=score; grade.status="brouillon"
    else: grade=Grade(assessment_code=assessment.code,student_matricule=student.matricule,score=score,entered_by=user.id); db.add(grade)
    db.add(AuditLog(user_id=user.id,action="SAISIE_NOTE",entity="Grade",entity_id=str(grade.id or ""),details=f"{student.matricule} — {assessment.code} : {score}")); db.commit()
    return {"message":"Note enregistrée","score":score}

@app.post("/grades/validate")
def grades_validate(p: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin","responsable_pedagogique","scolarite"))):
    code=str(p.get("assessment_code","")); rows=db.scalars(select(Grade).where(Grade.assessment_code==code)).all()
    if not rows: raise HTTPException(404,"Aucune note à valider")
    assessment=db.scalar(select(Assessment).where(Assessment.code==code)); course=db.scalar(select(Course).where(Course.code==assessment.course_code)) if assessment else None; ue=db.scalar(select(TeachingUnit).where(TeachingUnit.code==course.ue_code)) if course else None
    if ue:
        expected=db.scalars(select(Enrollment.student_matricule).where(Enrollment.program_code==ue.program_code,Enrollment.level_code==ue.level_code,Enrollment.status.in_(["en attente","validée","actif"]))).all()
        entered={g.student_matricule for g in rows}
        missing=sorted(set(expected)-entered)
        if missing: raise HTTPException(409,"Notes manquantes pour : "+", ".join(missing[:30]))
    for g in rows: g.status="validee"
    db.add(AuditLog(user_id=user.id,action="VALIDATION_NOTES",entity="Assessment",entity_id=code,details=f"Validation de {len(rows)} notes")); db.commit()
    return {"message":f"{len(rows)} notes validées et verrouillées"}

@app.post("/grades/publish")
def grades_publish(p: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin","scolarite"))):
    code=str(p.get("assessment_code","")); rows=db.scalars(select(Grade).where(Grade.assessment_code==code)).all()
    if not rows or any(g.status!="validee" for g in rows): raise HTTPException(409,"Toutes les notes doivent être validées avant publication")
    for g in rows: g.status="publiee"
    db.commit(); return {"message":f"{len(rows)} notes publiées"}

@app.get("/results")
def results_list(db: Session = Depends(get_db), user: User = Depends(current_user)):
    # Moyenne pondérée par cours pour chaque étudiant, sur les notes publiées.
    grades=db.execute(select(Grade,Assessment,Course,TeachingUnit).join(Assessment,Grade.assessment_code==Assessment.code).join(Course,Assessment.course_code==Course.code).join(TeachingUnit,Course.ue_code==TeachingUnit.code).where(Grade.status=="publiee")).all()
    acc={}
    for g,a,c,ue in grades:
        if user.role=="etudiant":
            st=db.scalar(select(Student).where(Student.matricule==user.username))
            if not st or st.matricule!=g.student_matricule: continue
        key=(g.student_matricule,ue.code,ue.title,ue.credits,ue.semester)
        slot=acc.setdefault(key,[0.0,0.0]); slot[0]+= (g.score/a.max_score*20)*a.weight*c.coefficient; slot[1]+=a.weight*c.coefficient
    out=[]; semester_acc={}
    try: threshold=float(db.scalar(select(AppSetting.value).where(AppSetting.key=="passing_grade")) or 10)
    except (TypeError,ValueError): threshold=10
    try: required_credits=int(db.scalar(select(AppSetting.value).where(AppSetting.key=="semester_credits")) or 30)
    except (TypeError,ValueError): required_credits=30
    for (mat,ue_code,ue_title,credits,semester),(total,weight) in acc.items():
        avg=round(total/weight,2) if weight else 0
        out.append({"matricule":mat,"type":"UE","ue_code":ue_code,"ue":ue_title,"semestre":semester,"credits":credits,"moyenne":avg,"decision":"Validée" if avg>=threshold else "Non validée"})
        slot=semester_acc.setdefault((mat,semester),[0.0,0.0,0])
        slot[0]+=avg*credits; slot[1]+=credits; slot[2]+=credits if avg>=threshold else 0
    for (mat,semester),(total,credits,validated) in semester_acc.items():
        avg=round(total/credits,2) if credits else 0
        out.append({"matricule":mat,"type":"SEMESTRE","ue_code":"—","ue":f"Moyenne {semester}","semestre":semester,"credits":validated,"moyenne":avg,"decision":"Validé" if avg>=threshold and validated>=required_credits else "Non validé"})
    return out

@app.get("/timetable")
def timetable_list(level_code: str = "", academic_year: str = "", db: Session = Depends(get_db), user: User = Depends(current_user)):
    stmt=select(TimetableEntry).order_by(TimetableEntry.weekday,TimetableEntry.starts_at)
    if level_code: stmt=stmt.where(TimetableEntry.level_code==level_code)
    if academic_year: stmt=stmt.where(TimetableEntry.academic_year==academic_year)
    return [{k:getattr(x,k) for k in ("id","course_code","academic_year","level_code","weekday","starts_at","ends_at","room","teacher_number")} for x in db.scalars(stmt).all()]

@app.post("/timetable", status_code=201)
def timetable_create(p: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin","responsable_pedagogique"))):
    try:
        day=int(p["weekday"]); start=str(p["starts_at"]); end=str(p["ends_at"])
        if day not in range(1,8) or not (len(start)==5 and len(end)==5 and start<end): raise ValueError()
    except Exception: raise HTTPException(422,"Jour ou plage horaire invalide (HH:MM)")
    if not db.scalar(select(Course).where(Course.code==p.get("course_code"))): raise HTTPException(422,"Cours inconnu")
    conflict_query=select(TimetableEntry).where(TimetableEntry.academic_year==p.get("academic_year"),TimetableEntry.weekday==day,TimetableEntry.starts_at<end,TimetableEntry.ends_at>start)
    conflict_query=conflict_query.where(or_(TimetableEntry.level_code==p.get("level_code"),and_(str(p.get("room",""))!="",TimetableEntry.room==str(p.get("room",""))),and_(str(p.get("teacher_number",""))!="",TimetableEntry.teacher_number==str(p.get("teacher_number","")))))
    conflict=db.scalar(conflict_query)
    if conflict: raise HTTPException(409,"Conflit d'horaire pour ce niveau")
    item=TimetableEntry(course_code=p["course_code"],academic_year=p["academic_year"],level_code=p["level_code"],weekday=day,starts_at=start,ends_at=end,room=str(p.get("room","")),teacher_number=str(p.get("teacher_number","")))
    db.add(item); db.commit(); db.refresh(item)
    return {k:getattr(item,k) for k in ("id","course_code","academic_year","level_code","weekday","starts_at","ends_at","room","teacher_number")}

@app.get("/audit")
def audit_list(db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    return [{"id":x.id,"action":x.action,"entity":x.entity,"entity_id":x.entity_id,"details":x.details,"created_at":x.created_at.isoformat(),"user_id":x.user_id} for x in db.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(1000)).all()]

@app.get("/settings")
def settings_list(db: Session = Depends(get_db), user: User = Depends(require_roles("admin","responsable_pedagogique"))):
    defaults={"passing_grade":"10","max_grade":"20","semester_credits":"30","academic_system":"LMD"}
    rows={x.key:x.value for x in db.scalars(select(AppSetting)).all()}
    return {**defaults,**rows}

@app.put("/settings")
def settings_update(p: dict = Body(...), db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    allowed={"passing_grade","max_grade","semester_credits","academic_system"}
    if set(p)-allowed: raise HTTPException(422,"Paramètre non autorisé")
    for k,v in p.items():
        try: float(v)
        except (ValueError,TypeError):
            if k!="academic_system": raise HTTPException(422,f"Valeur invalide : {k}")
        row=db.scalar(select(AppSetting).where(AppSetting.key==k))
        if row: row.value=str(v)
        else: db.add(AppSetting(key=k,value=str(v)))
    db.commit(); return settings_list(db,user)

@app.get("/exports/results.csv")
def export_results(db: Session = Depends(get_db), user: User = Depends(require_roles("admin","scolarite","responsable_pedagogique","direction"))):
    rows=results_list(db,user)
    stream=io.StringIO(newline=""); writer=csv.DictWriter(stream,fieldnames=["matricule","ue_code","ue","credits","moyenne","decision"],delimiter=";"); writer.writeheader(); writer.writerows(rows)
    return StreamingResponse(iter(["\ufeff"+stream.getvalue()]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=resultats.csv"})

@app.get("/students/{matricule}/transcript.pdf")
def student_transcript_pdf(matricule: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    student=db.scalar(select(Student).where(Student.matricule==matricule))
    if not student: raise HTTPException(404,"Étudiant introuvable")
    if user.role=="etudiant" and user.username!=matricule: raise HTTPException(403,"Accès limité à votre propre relevé")
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
    except ImportError: raise HTTPException(503,"Le module PDF n'est pas installé")
    rows=results_list(db,user)
    rows=[r for r in rows if r["matricule"]==matricule]
    buffer=io.BytesIO(); pdf=canvas.Canvas(buffer,pagesize=A4); width,height=A4
    pdf.setTitle(f"Relevé de notes - {matricule}")
    pdf.setFont("Helvetica-Bold",16); pdf.drawString(48,height-55,"UNIVERSITÉ DE MAROUA")
    pdf.setFont("Helvetica-Bold",13); pdf.drawString(48,height-82,"RELEVÉ DE NOTES — DOCUMENT DE DÉMONSTRATION TPE")
    pdf.setFont("Helvetica",10); pdf.drawString(48,height-112,f"Étudiant : {student.last_name} {student.first_name}")
    pdf.drawString(48,height-128,f"Matricule : {student.matricule}")
    y=height-170; pdf.setFont("Helvetica-Bold",9); pdf.drawString(48,y,"Code UE"); pdf.drawString(145,y,"Unité d'enseignement"); pdf.drawString(390,y,"Crédits"); pdf.drawString(455,y,"Moyenne")
    y-=18; pdf.setFont("Helvetica",9)
    for row in rows:
        if y<65: pdf.showPage(); y=height-60; pdf.setFont("Helvetica",9)
        pdf.drawString(48,y,str(row["ue_code"])[:15]); pdf.drawString(145,y,str(row["ue"])[:38]); pdf.drawRightString(425,y,str(row["credits"])); pdf.drawRightString(510,y,str(row["moyenne"])); y-=17
    pdf.setFont("Helvetica-Oblique",8); pdf.drawString(48,35,"Document généré par SCOLARITÉ UMa — données pédagogiques de démonstration.")
    pdf.save(); buffer.seek(0)
    return StreamingResponse(buffer,media_type="application/pdf",headers={"Content-Disposition":f"attachment; filename=releve_{matricule}.pdf"})

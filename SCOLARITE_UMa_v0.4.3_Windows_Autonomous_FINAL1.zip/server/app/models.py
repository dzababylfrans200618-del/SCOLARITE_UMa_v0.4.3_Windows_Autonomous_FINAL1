from datetime import datetime, date
from sqlalchemy import String, Integer, Date, DateTime, Boolean, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30), default="scolarite")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Student(Base):
    __tablename__ = "students"
    __table_args__ = (UniqueConstraint("matricule", name="uq_student_matricule"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    matricule: Mapped[str] = mapped_column(String(40), index=True)
    last_name: Mapped[str] = mapped_column(String(100), index=True)
    first_name: Mapped[str] = mapped_column(String(120))
    sex: Mapped[str] = mapped_column(String(1), default="")
    birth_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    phone: Mapped[str] = mapped_column(String(40), default="")
    email: Mapped[str] = mapped_column(String(160), default="")
    program: Mapped[str] = mapped_column(String(160), default="")
    level: Mapped[str] = mapped_column(String(40), default="")
    status: Mapped[str] = mapped_column(String(30), default="actif")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(80))
    entity: Mapped[str] = mapped_column(String(80))
    entity_id: Mapped[str] = mapped_column(String(80), default="")
    details: Mapped[str] = mapped_column(String(1000), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

# Référentiels académiques et opérations de scolarité.
# Ces tables sont ajoutées sans modifier ni supprimer les tables existantes.
class Faculty(Base):
    __tablename__ = "faculties"
    __table_args__ = (UniqueConstraint("code", name="uq_faculty_code"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), index=True)
    name: Mapped[str] = mapped_column(String(160))
    description: Mapped[str] = mapped_column(String(500), default="")
    status: Mapped[str] = mapped_column(String(30), default="actif")

class Department(Base):
    __tablename__ = "departments"
    __table_args__ = (UniqueConstraint("code", name="uq_department_code"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), index=True)
    name: Mapped[str] = mapped_column(String(160))
    faculty_code: Mapped[str] = mapped_column(String(30), ForeignKey("faculties.code"), index=True)
    description: Mapped[str] = mapped_column(String(500), default="")
    status: Mapped[str] = mapped_column(String(30), default="actif")

class Program(Base):
    __tablename__ = "programs"
    __table_args__ = (UniqueConstraint("code", name="uq_program_code"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), index=True)
    name: Mapped[str] = mapped_column(String(160))
    department_code: Mapped[str] = mapped_column(String(30), ForeignKey("departments.code"), index=True)
    description: Mapped[str] = mapped_column(String(500), default="")
    status: Mapped[str] = mapped_column(String(30), default="actif")

class AcademicLevel(Base):
    __tablename__ = "academic_levels"
    __table_args__ = (UniqueConstraint("code", name="uq_academic_level_code"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), index=True)
    name: Mapped[str] = mapped_column(String(80))
    rank: Mapped[int] = mapped_column(Integer, default=1)
    description: Mapped[str] = mapped_column(String(500), default="")
    status: Mapped[str] = mapped_column(String(30), default="actif")

class AcademicYear(Base):
    __tablename__ = "academic_years"
    __table_args__ = (UniqueConstraint("year_label", name="uq_academic_year_label"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    year_label: Mapped[str] = mapped_column(String(30), index=True)
    start_date: Mapped[str] = mapped_column(String(10), default="")
    end_date: Mapped[str] = mapped_column(String(10), default="")
    status: Mapped[str] = mapped_column(String(30), default="prévue")

class Teacher(Base):
    __tablename__ = "teachers"
    __table_args__ = (UniqueConstraint("employee_number", name="uq_teacher_employee_number"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    employee_number: Mapped[str] = mapped_column(String(40), index=True)
    last_name: Mapped[str] = mapped_column(String(100))
    first_name: Mapped[str] = mapped_column(String(120), default="")
    specialty: Mapped[str] = mapped_column(String(160), default="")
    email: Mapped[str] = mapped_column(String(160), default="")
    phone: Mapped[str] = mapped_column(String(40), default="")
    status: Mapped[str] = mapped_column(String(30), default="actif")

class TeachingUnit(Base):
    __tablename__ = "teaching_units"
    __table_args__ = (UniqueConstraint("code", name="uq_teaching_unit_code"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), index=True)
    title: Mapped[str] = mapped_column(String(160))
    credits: Mapped[int] = mapped_column(Integer, default=0)
    coefficient: Mapped[float] = mapped_column(default=1.0)
    semester: Mapped[str] = mapped_column(String(20), default="")
    program_code: Mapped[str] = mapped_column(String(30), ForeignKey("programs.code"), index=True)
    level_code: Mapped[str] = mapped_column(String(30), ForeignKey("academic_levels.code"), index=True)
    status: Mapped[str] = mapped_column(String(30), default="actif")

class Course(Base):
    __tablename__ = "courses"
    __table_args__ = (UniqueConstraint("code", name="uq_course_code"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), index=True)
    title: Mapped[str] = mapped_column(String(160))
    coefficient: Mapped[float] = mapped_column(default=1.0)
    ue_code: Mapped[str] = mapped_column(String(30), ForeignKey("teaching_units.code"), index=True)
    teacher_number: Mapped[str] = mapped_column(String(40), default="", index=True)
    status: Mapped[str] = mapped_column(String(30), default="actif")

class Enrollment(Base):
    __tablename__ = "enrollments"
    __table_args__ = (UniqueConstraint("student_matricule", "program_code", "academic_year", name="uq_enrollment_student_program_year"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    student_matricule: Mapped[str] = mapped_column(String(40), ForeignKey("students.matricule"), index=True)
    program_code: Mapped[str] = mapped_column(String(30), ForeignKey("programs.code"), index=True)
    level_code: Mapped[str] = mapped_column(String(30), ForeignKey("academic_levels.code"), index=True)
    academic_year: Mapped[str] = mapped_column(String(30), ForeignKey("academic_years.year_label"), index=True)
    registration_type: Mapped[str] = mapped_column(String(30), default="Première inscription")
    status: Mapped[str] = mapped_column(String(30), default="en attente")

class ExamSession(Base):
    __tablename__ = "exam_sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(160))
    academic_year: Mapped[str] = mapped_column(String(30), ForeignKey("academic_years.year_label"))
    semester: Mapped[str] = mapped_column(String(20))
    starts_on: Mapped[str] = mapped_column(String(10), default="")
    ends_on: Mapped[str] = mapped_column(String(10), default="")
    status: Mapped[str] = mapped_column(String(30), default="ouverte")

class Assessment(Base):
    __tablename__ = "assessments"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(160))
    course_code: Mapped[str] = mapped_column(String(30), ForeignKey("courses.code"))
    session_code: Mapped[str] = mapped_column(String(40), ForeignKey("exam_sessions.code"))
    weight: Mapped[float] = mapped_column(default=1.0)
    max_score: Mapped[float] = mapped_column(default=20.0)
    status: Mapped[str] = mapped_column(String(30), default="ouverte")

class Grade(Base):
    __tablename__ = "grades"
    __table_args__ = (UniqueConstraint("assessment_code", "student_matricule", name="uq_grade_assessment_student"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    assessment_code: Mapped[str] = mapped_column(String(40), ForeignKey("assessments.code"), index=True)
    student_matricule: Mapped[str] = mapped_column(String(40), ForeignKey("students.matricule"), index=True)
    score: Mapped[float] = mapped_column()
    status: Mapped[str] = mapped_column(String(30), default="brouillon")
    entered_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class TimetableEntry(Base):
    __tablename__ = "timetable_entries"
    id: Mapped[int] = mapped_column(primary_key=True)
    course_code: Mapped[str] = mapped_column(String(30), ForeignKey("courses.code"))
    academic_year: Mapped[str] = mapped_column(String(30), ForeignKey("academic_years.year_label"))
    level_code: Mapped[str] = mapped_column(String(30), ForeignKey("academic_levels.code"))
    weekday: Mapped[int] = mapped_column(Integer)  # 1=lundi ... 7=dimanche
    starts_at: Mapped[str] = mapped_column(String(5))
    ends_at: Mapped[str] = mapped_column(String(5))
    room: Mapped[str] = mapped_column(String(80))
    teacher_number: Mapped[str] = mapped_column(String(40), default="")

class AppSetting(Base):
    __tablename__ = "app_settings"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(80), unique=True)
    value: Mapped[str] = mapped_column(String(500))

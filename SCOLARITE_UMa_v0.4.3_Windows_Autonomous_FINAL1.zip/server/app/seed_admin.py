import os, getpass
from sqlalchemy import select
from .database import Base, engine, SessionLocal
from .models import User
from .security import hash_password

Base.metadata.create_all(bind=engine)
db = SessionLocal()
try:
    username = os.getenv("ADMIN_USERNAME", "admin")
    full_name = os.getenv("ADMIN_FULL_NAME", "Administrateur principal")
    existing = db.scalar(select(User).where(User.username == username))
    if existing:
        print(f"Le compte {username} existe déjà.")
    else:
        password = os.getenv("ADMIN_PASSWORD") or getpass.getpass("Mot de passe administrateur (12 caractères minimum) : ")
        if len(password) < 12:
            raise SystemExit("Mot de passe trop court : 12 caractères minimum.")
        db.add(User(username=username, full_name=full_name, password_hash=hash_password(password), role="admin"))
        db.commit()
        print(f"Compte administrateur {username} créé.")
finally:
    db.close()

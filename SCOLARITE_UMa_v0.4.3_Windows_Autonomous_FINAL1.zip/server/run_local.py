"""Entrée du serveur local empaqueté pour Windows."""
import os
from pathlib import Path
import logging
import uvicorn


def main():
    root = Path(os.environ.get("SCOLARITE_DATA_DIR", Path.home() / "SCOLARITE UMa" / "data"))
    logs = root.parent / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    root.mkdir(parents=True, exist_ok=True)
    os.environ["SCOLARITE_DATA_DIR"] = str(root)
    logging.basicConfig(
        filename=str(logs / "server.log"),
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        encoding="utf-8",
    )
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, log_level="info")


if __name__ == "__main__":
    main()

import io
import unittest
from openpyxl import Workbook
from app.imports import read_tabular_file, normalize_import_value

FIELDS = ["matricule", "last_name", "first_name", "birth_date"]
REQUIRED = ["matricule", "last_name", "first_name"]

class ImportParserTests(unittest.TestCase):
    def test_csv_semicolon_utf8_bom(self):
        data = "\ufeffmatricule;last_name;first_name\nUM001;DUPONT;Élise\n".encode("utf-8")
        rows, errors = read_tabular_file(data, "students.csv", FIELDS, REQUIRED)
        self.assertEqual(errors, [])
        self.assertEqual(rows[0]["matricule"], "UM001")
        self.assertEqual(rows[0]["first_name"], "Élise")

    def test_csv_french_headers(self):
        data = "Matricule;Nom;Prénom(s)\nUM002;MBOG;Paul\n".encode()
        rows, _ = read_tabular_file(data, "students.csv", FIELDS, REQUIRED)
        self.assertEqual(rows[0]["last_name"], "MBOG")

    def test_xlsx(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(FIELDS)
        sheet.append(["UM003", "KANA", "Rose", "2004-03-02"])
        buffer = io.BytesIO()
        workbook.save(buffer)
        rows, _ = read_tabular_file(buffer.getvalue(), "students.xlsx", FIELDS, REQUIRED)
        self.assertEqual(rows[0]["first_name"], "Rose")

    def test_missing_required_header_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Colonnes obligatoires absentes"):
            read_tabular_file(b"matricule;last_name\nUM004;TEST\n", "bad.csv", FIELDS, REQUIRED)

    def test_birth_date_formats(self):
        self.assertEqual(str(normalize_import_value("birth_date", "15/09/2003")), "2003-09-15")

    def test_french_decimal(self):
        self.assertEqual(normalize_import_value("coefficient", "1,5"), 1.5)

if __name__ == "__main__":
    unittest.main()
